// proc-pattern-trigger
// Safe sandbox-only test package.
// Goal: trigger proc_* and pattern_* features in the dynamic analyzer.
// No data exfiltration and no malicious external domain contact.

const fs = require("fs");
const { execSync, spawn, spawnSync } = require("child_process");

function run(cmd, timeout = 20000) {
  try {
    console.log("[proc-pattern-trigger] RUN:", cmd);
    execSync(cmd, { stdio: "ignore", timeout });
  } catch (e) {
    console.log("[proc-pattern-trigger] ignored:", cmd);
  }
}

console.log("[proc-pattern-trigger] starting");

// 1) proc_write_binary_dir: keep /usr/bin file handle open
let binaryFd = null;
try {
  binaryFd = fs.openSync("/usr/bin/proc_feature_binary_trigger", "w");
  fs.writeSync(binaryFd, "#!/bin/sh\necho proc write binary dir trigger\n");
  fs.fchmodSync(binaryFd, 0o777);
} catch (e) {
  console.log("[proc-pattern-trigger] /usr/bin write failed, ignored");
}

// 2) proc_package_install_runtime: long-running fake package-manager cmdlines
const children = [];
try {
  children.push(spawn("/bin/sh", ["-c", "exec -a pip sleep 45"], { stdio: "ignore" }));
  children.push(spawn("/bin/sh", ["-c", "exec -a npm sleep 45"], { stdio: "ignore" }));
  children.push(spawn("/bin/sh", ["-c", "exec -a apt-get sleep 45"], { stdio: "ignore" }));
} catch (e) {}

run("pip --version || true", 8000);
run("npm --version || true", 8000);
run("apt-get --version || true", 8000);

// 3) proc_ptrace_detected + pattern_process_injection
// Runner already uses strace -f, so TracerPid should become >0.
// Also attempt ptrace and /proc/self/mem access.
run(`python3 - <<'PY'
import ctypes, time
libc = ctypes.CDLL("libc.so.6")
try:
    libc.ptrace(0, 0, None, None)
except Exception:
    pass
try:
    open("/proc/self/mem", "rb").read(1)
except Exception:
    pass
time.sleep(12)
PY`, 20000);

// 4) proc_privilege_escalation: setuid-root helper executed with real uid 65534
try {
  fs.writeFileSync("/tmp/suid_helper.c", `
#include <unistd.h>
int main() {
  setuid(0);
  seteuid(0);
  sleep(35);
  return 0;
}
`);
  run("gcc /tmp/suid_helper.c -o /tmp/suid_helper", 20000);
  run("chown root:root /tmp/suid_helper || true", 8000);
  run("chmod 4755 /tmp/suid_helper || true", 8000);

  const suidChild = spawn("/tmp/suid_helper", [], {
    detached: false,
    stdio: "ignore",
    uid: 65534,
    gid: 65534
  });
  children.push(suidChild);
} catch (e) {
  console.log("[proc-pattern-trigger] setuid helper failed, ignored");
}

// 5) pattern_malicious_probing: many missing/sensitive path probes
const probes = [
  "/root/.ssh/id_rsa",
  "/root/.aws/credentials",
  "/home/admin/.ssh/id_rsa",
  "/home/ubuntu/.aws/credentials",
  "/etc/kubernetes/admin.conf",
  "/var/run/secrets/kubernetes.io/serviceaccount/token",
  "/tmp/nonexistent_secret_1",
  "/tmp/nonexistent_secret_2",
  "/tmp/nonexistent_secret_3"
];

for (const p of probes) {
  try { fs.statSync(p); } catch (e) {}
  try { fs.openSync(p, "r"); } catch (e) {}
}

// 6) pattern_file_locking: hold flock
try {
  fs.writeFileSync("/tmp/proc_pattern_lock_file", "lock-test\n");
  children.push(spawn("/bin/sh", ["-c", "flock /tmp/proc_pattern_lock_file -c 'sleep 35'"], { stdio: "ignore" }));
} catch (e) {}

// 7) pattern_privilege_escalation
run("chmod 777 /tmp/proc_pattern_lock_file || true", 8000);
run("chmod u+s /tmp/suid_helper || true", 8000);

// 8) Keep alive for monitor
spawnSync("/bin/sh", ["-c", "sleep 45"], { stdio: "ignore" });

try {
  if (binaryFd !== null) fs.closeSync(binaryFd);
} catch (e) {}

for (const c of children) {
  try { c.kill(); } catch (e) {}
}

console.log("[proc-pattern-trigger] completed");
