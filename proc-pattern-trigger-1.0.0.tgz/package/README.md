# proc-pattern-trigger

Safe test package for your sandbox.

Designed to trigger:
- proc_privilege_escalation
- proc_write_binary_dir
- proc_ptrace_detected
- proc_package_install_runtime
- pattern_malicious_probing
- pattern_privilege_escalation
- pattern_file_locking
- pattern_process_injection

For controlled CI/sandbox testing only.
