// falco-hard-trigger
// Safe CI/sandbox test package for Falco validation.
// Purpose: generate syscall behavior that commonly matches Falco rules.
// It does not exfiltrate data and does not contact malicious domains.

const fs = require("fs");
const { execSync, spawnSync } = require("child_process");

function run(cmd, timeout = 15000) {
  try {
    console.log("[falco-hard-trigger] RUN:", cmd);
    execSync(cmd, { stdio: "inherit", timeout });
  } catch (e) {
    console.log("[falco-hard-trigger] ignored error:", cmd);
  }
}

function sleep(seconds) {
  run(`/bin/sh -c "sleep ${seconds}"`, (seconds + 2) * 1000);
}

console.log("[falco-hard-trigger] starting");

// ------------------------------------------------------------
// 1) Shell execution inside container
// ------------------------------------------------------------
run(`/bin/bash -c "echo falco shell trigger; id; whoami; sleep 5"`);
run(`/bin/sh -c "echo falco sh trigger; sleep 5"`);

// ------------------------------------------------------------
// 2) Sensitive file access attempts
// ------------------------------------------------------------
run(`/bin/sh -c "cat /etc/passwd > /tmp/falco_passwd_copy 2>/dev/null || true"`);
run(`/bin/sh -c "cat /etc/shadow > /tmp/falco_shadow_copy 2>/dev/null || true"`);

// ------------------------------------------------------------
// 3) Privilege-escalation style chmod behavior
// ------------------------------------------------------------
run(`/bin/sh -c "echo test > /tmp/falco_chmod_target && chmod 777 /tmp/falco_chmod_target && ls -l /tmp/falco_chmod_target"`);

// ------------------------------------------------------------
// 4) Write below binary directory
// This commonly triggers Falco rules such as write below binary dir.
// If permission fails, the attempt is still useful for debugging.
// ------------------------------------------------------------
run(`/bin/sh -c "echo '#!/bin/sh' > /usr/bin/falco_ci_trigger 2>/dev/null || true"`);
run(`/bin/sh -c "echo 'echo falco trigger' >> /usr/bin/falco_ci_trigger 2>/dev/null || true"`);
run(`/bin/sh -c "chmod +x /usr/bin/falco_ci_trigger 2>/dev/null || true"`);

// ------------------------------------------------------------
// 5) Ptrace / memory-access style behavior
// ------------------------------------------------------------
run(`/bin/sh -c "python3 - <<'PY'
import ctypes, os, time
libc = ctypes.CDLL('libc.so.6')
PTRACE_TRACEME = 0
try:
    libc.ptrace(PTRACE_TRACEME, 0, None, None)
except Exception:
    pass
try:
    open('/proc/self/mem', 'rb').read(1)
except Exception:
    pass
time.sleep(5)
PY"`);

// ------------------------------------------------------------
// 6) Package manager execution at runtime
// These commands avoid installing anything but still execute package managers.
// Custom Falco rules often match apt-get/npm/pip process execution.
// ------------------------------------------------------------
run(`/bin/sh -c "apt-get --version >/tmp/falco_apt_version 2>&1 || true"`);
run(`/bin/sh -c "npm --version >/tmp/falco_npm_version 2>&1 || true"`);
run(`/bin/sh -c "pip --version >/tmp/falco_pip_version 2>&1 || true"`);

// ------------------------------------------------------------
// 7) Keep alive to give Falco time to collect/write alerts
// ------------------------------------------------------------
sleep(20);

console.log("[falco-hard-trigger] completed");
