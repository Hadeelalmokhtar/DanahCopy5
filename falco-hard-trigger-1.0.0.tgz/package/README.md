# falco-hard-trigger

Safe CI/sandbox package for validating Falco integration.

It attempts to trigger Falco alerts through:
- shell execution
- sensitive file access
- chmod 777
- writing below /usr/bin
- ptrace / /proc/self/mem access
- runtime package-manager execution
- long sleeps for event capture

It does not exfiltrate data and does not contact malicious domains.
