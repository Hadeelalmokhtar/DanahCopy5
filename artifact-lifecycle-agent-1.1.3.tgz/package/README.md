# artifact-lifecycle-agent

Safe synthetic malicious-style NPM fixture. It uses one CSV-selected domain as an indicator and sends HTTP only to the local sandbox server.
