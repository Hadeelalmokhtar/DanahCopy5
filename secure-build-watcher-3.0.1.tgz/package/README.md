# secure-build-watcher

Safe controlled npm package for dynamic analysis retraining.

Level: High maliciousness
Expected probability target: around 0.94
Single malicious domain from CSV: bitkit.vexo3nar.surf
HTTP method trigger: synchronous curl GET + POST to 127.0.0.1:8080 decoy server
Ports: 4444|1337|6667|8080|2323
