# config-sync-runtime
Level: Medium
Ports: 8080, 1234
