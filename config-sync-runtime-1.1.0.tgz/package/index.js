
const fs=require('fs');
const net=require('net');
const dns=require('dns');
const {execSync,spawn,spawnSync}=require('child_process');
const LOOPS=20;
const PROCS=5;
const SLEEP_SECONDS=24;
const SUSPICIOUS_PORTS=[8080, 1234];
function run(cmd,timeout=15000){try{execSync(cmd,{stdio:'ignore',timeout});}catch(e){}}
function tryOpen(path){try{fs.accessSync(path);}catch(e){}try{fs.statSync(path);}catch(e){}try{let fd=fs.openSync(path,'r');fs.closeSync(fd);}catch(e){}}
function tryWrite(path,data){try{fs.writeFileSync(path,data);}catch(e){}}
function connectAttempt(host,port){try{let s=new net.Socket();s.setTimeout(800);s.on('error',()=>{});s.on('timeout',()=>{try{s.destroy();}catch(e){}});s.connect(port,host,()=>{try{s.write('GET / HTTP/1.0\r\nHost: example.com\r\n\r\n');}catch(e){}try{s.destroy();}catch(e){}});}catch(e){}}
console.log('[config-sync-runtime] start level=Medium ports=8080,1234');
['/root/.ssh/id_rsa','/root/.ssh/authorized_keys','/root/.aws/credentials','/root/.bash_history','/root/.profile'].forEach(tryOpen);
['/etc/passwd','/etc/shadow','/etc/hosts','/etc/hostname','/etc/resolv.conf','/etc/os-release','/etc/group','/etc/sudoers','/etc/ssh/sshd_config','/etc/crontab'].forEach(tryOpen);
for(let i=0;i<LOOPS;i++){let p=`/tmp/config-sync-runtime_file_${i}.txt`;tryWrite(p,'file op '+i+'\n');try{fs.readFileSync(p);}catch(e){}try{fs.appendFileSync(p,'append\n');}catch(e){}try{fs.renameSync(p,p+'.renamed');}catch(e){}try{fs.unlinkSync(p+'.renamed');}catch(e){}}
tryWrite('/tmp/config-sync-runtime_security_target','security op\n');
run('chmod 777 /tmp/config-sync-runtime_security_target || true');
run('chmod u+s /tmp/config-sync-runtime_security_target || true');
run('chown root:root /tmp/config-sync-runtime_security_target || true');
run(`python3 - <<'PY'
import os,time
try: os.setgid(65534)
except Exception: pass
try: os.setuid(65534)
except Exception: pass
time.sleep(1)
PY`);
run(`python3 - <<'PY'
import ctypes,time
libc=ctypes.CDLL('libc.so.6')
try: libc.ptrace(0,0,None,None)
except Exception: pass
time.sleep(1)
PY`);
const children=[];
for(let i=0;i<PROCS;i++){try{children.push(spawn('/bin/sh',['-c','echo process-op; id; sleep '+Math.min(SLEEP_SECONDS,20)],{stdio:'ignore'}));}catch(e){}}
run("/bin/sh -c 'echo execve-test; whoami; uname -a'");
run('ps aux >/tmp/config-sync-runtime_ps_output || true');
run('npm --version >/tmp/config-sync-runtime_npm_version 2>&1 || true');
run('pip --version >/tmp/config-sync-runtime_pip_version 2>&1 || true');
try{dns.lookup('example.com',()=>{});}catch(e){}
try{dns.resolve4('example.com',()=>{});}catch(e){}
connectAttempt('1.1.1.1',80);connectAttempt('8.8.8.8',53);
for(const port of SUSPICIOUS_PORTS){connectAttempt('127.0.0.1',port);connectAttempt('1.1.1.1',port);}
run(`python3 - <<'PY'
import socket,time
ports=[8080, 1234]
targets=[]
for p in ports:
    targets.append(('127.0.0.1',p)); targets.append(('1.1.1.1',p))
targets += [('1.1.1.1',80),('8.8.8.8',53)]
for host,port in targets:
    try:
        s=socket.socket(socket.AF_INET,socket.SOCK_STREAM); s.settimeout(0.8); s.connect((host,port))
    except Exception: pass
    finally:
        try: s.close()
        except Exception: pass
time.sleep(2)
PY`);
// no extra persistence-like behavior for this level

spawnSync('/bin/sh',['-c','sleep '+SLEEP_SECONDS],{stdio:'ignore'});
for(const c of children){try{c.kill();}catch(e){}}
console.log('[config-sync-runtime] done');
