const { execSync, spawn } = require("child_process");
const fs = require("fs");
const net = require("net");
const os = require("os");
const path = require("path");

console.log("[test-pkg] starting all feature triggers...");

// ── 1. FILE ACCESS (opensnoop) ──
// Access /etc directory → ebpf_accessed_etc
try { fs.readdirSync("/etc"); console.log("[test-pkg] /etc accessed"); } catch(e) {}
// Access /root directory → ebpf_accessed_root  
try { fs.readdirSync("/root"); console.log("[test-pkg] /root accessed"); } catch(e) {}
// Access .ssh directory → ebpf_accessed_ssh
try { fs.readdirSync(os.homedir() + "/.ssh"); console.log("[test-pkg] .ssh accessed"); } catch(e) {}

// ── 2. SECURITY SYSCALLS (strace → ebpf_security_ops) ──
// chmod → capget → these are called internally by node when running chmod
try { fs.chmodSync("/tmp/test_file_ssc", 0o777); } catch(e) {}
try { execSync("chmod 777 /tmp/test_file_ssc 2>/dev/null || true"); } catch(e) {}
try { execSync("chmod u+s /tmp/test_file_ssc 2>/dev/null || true"); } catch(e) {}

// ── 3. NETWORK SYSCALLS (strace → ebpf_network_ops + tcpconnect) ──
// socket + connect → ebpf_network_ops, ebpf_network_activity
const targets = [
    { host: "1.1.1.1", port: 80 },      // normal
    { host: "127.0.0.1", port: 4444 },   // C2 port → ebpf_c2_port_suspected
    { host: "127.0.0.1", port: 6667 },   // C2 port
    { host: "127.0.0.1", port: 1337 },   // C2 port
];

let pending = targets.length;
targets.forEach(({ host, port }) => {
    const s = new net.Socket();
    s.setTimeout(1000);
    s.connect(port, host, () => { s.destroy(); });
    s.on("error", () => { s.destroy(); });
    s.on("timeout", () => { s.destroy(); });
    s.on("close", () => { pending--; });
});

// ── 4. PROCESS SYSCALLS (strace → ebpf_process_ops, ebpf_spawned_process) ──
// clone + execve → spawn child processes
try { execSync("echo execve-test"); } catch(e) {}
try { execSync("ps aux > /tmp/ps_output 2>/dev/null || true"); } catch(e) {}
try { execSync("ls /tmp > /tmp/ls_output 2>/dev/null || true"); } catch(e) {}
try { execSync("whoami > /tmp/whoami_output 2>/dev/null || true"); } catch(e) {}

// ── 5. SENSITIVE FILE ACCESS (honeytokens → sensitive_file_read) ──
try { fs.readFileSync("/app/decoy_logs/aws_credentials.txt"); } catch(e) {}
try { fs.readFileSync(os.homedir() + "/.aws/credentials"); } catch(e) {}

// ── 6. DNS QUERY (honeypot → dns_query_to_external) ──
const dns = require("dns");
try { dns.lookup("google.com", () => {}); } catch(e) {}
try { dns.lookup("evil-c2-server.com", () => {}); } catch(e) {}

// ── 7. HTTP REQUEST (honeypot → http_method, contacted_external_domain) ──
const http = require("http");
try {
    http.get("http://1.1.1.1", (res) => { res.destroy(); }).on("error", () => {});
} catch(e) {}

// Wait for network ops to complete
setTimeout(() => {
    console.log("[test-pkg] all triggers fired ✅");
}, 3000);
