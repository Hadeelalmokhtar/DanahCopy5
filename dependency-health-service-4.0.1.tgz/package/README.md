# dependency-health-service

Safe controlled npm package for dynamic analysis retraining.

Level: Critical maliciousness
Expected probability target: around 0.96+
Single malicious domain from CSV: echo-sync.sorix7en.surf
HTTP method trigger: synchronous curl GET + POST to 127.0.0.1:8080 decoy server
Ports: 4444|1337|6667|31337|9001|8080|2323|1234
