# workspace-profile-loader

Safe synthetic malicious NPM fixture for CTI/dynamic-analysis training.

- DNS behavior: one local DNS query carrying `echo-sync.sorix7en.surf`
- HTTP behavior: local HTTP `GET` request with Host header `echo-sync.sorix7en.surf`
- Risk probability: `0.74`
- Profile: `dns_http_persistence_only`

This fixture is for controlled sandbox analysis only.
