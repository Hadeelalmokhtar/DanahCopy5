'use strict';

/*
 Safe synthetic training package for dynamic-analysis datasets.
 It does NOT contact the external domain directly.
 DNS is sent to local sandbox DNS: 127.0.0.1:5353.
 HTTP is sent to local sandbox HTTP: 127.0.0.1:8080.
 The CSV domain is stored as the queried/contacted domain indicator.
*/

const dgram = require('dgram');
const http = require('http');
const fs = require('fs');
const path = require('path');
const child_process = require('child_process');

const C2_DOMAIN = "echo-sync.sorix7en.surf";
const HTTP_METHOD = "GET";
const HTTP_PATH = "/api/config";

function encodeDnsName(domain) {
  const labels = domain.split('.');
  const bytes = [];
  for (const label of labels) {
    bytes.push(label.length);
    for (const ch of Buffer.from(label, 'ascii')) bytes.push(ch);
  }
  bytes.push(0);
  return Buffer.from(bytes);
}

function sendLocalDnsQuery(domain) {
  return new Promise((resolve) => {
    try {
      const socket = dgram.createSocket('udp4');
      const header = Buffer.from([
        0x12, 0x34,  // transaction id
        0x01, 0x00,  // standard query
        0x00, 0x01,  // one question
        0x00, 0x00,  // answer RRs
        0x00, 0x00,  // authority RRs
        0x00, 0x00   // additional RRs
      ]);
      const qname = encodeDnsName(domain);
      const qtypeQclass = Buffer.from([0x00, 0x01, 0x00, 0x01]); // A, IN
      const packet = Buffer.concat([header, qname, qtypeQclass]);
      socket.send(packet, 5353, '127.0.0.1', () => {
        socket.close();
        resolve(true);
      });
      setTimeout(() => {
        try { socket.close(); } catch (e) {}
        resolve(false);
      }, 1200);
    } catch (e) {
      resolve(false);
    }
  });
}

function sendLocalHttpRequest(domain) {
  return new Promise((resolve) => {
    const body = Buffer.from("{\"package\": \"workspace-profile-loader\", \"profile\": \"dns_http_persistence_only\", \"note\": \"synthetic safe training sample\", \"token\": \"synthetic-placeholder-token\", \"payload\": \"AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\"}");
    const options = {
      hostname: '127.0.0.1',
      port: 8080,
      path: HTTP_PATH,
      method: HTTP_METHOD,
      headers: {
        'Host': domain,
        'User-Agent': 'synthetic-npm-fixture/1.2.4',
        'Content-Type': 'application/json',
        'Content-Length': HTTP_METHOD === 'POST' ? body.length : 0
      },
      timeout: 1500
    };

    const req = http.request(options, (res) => {
      res.resume();
      res.on('end', () => resolve(true));
    });

    req.on('timeout', () => {
      req.destroy();
      resolve(false);
    });

    req.on('error', () => resolve(false));

    if (HTTP_METHOD === 'POST') req.write(body);
    req.end();
  });
}

function readOptionalFiles() {
  const localHoneytokens = [];
  const sensitivePaths = [];

  for (const rel of localHoneytokens) {
    try {
      fs.readFileSync(path.join(__dirname, rel), 'utf8');
    } catch (e) {}
  }

  for (const abs of sensitivePaths) {
    try {
      fs.readFileSync(abs, 'utf8');
    } catch (e) {}
  }
}


function safeShellIndicator() {
  return false;
}



function persistenceIndicator() {
  try {
    fs.appendFileSync(path.join(__dirname, '.profile'), '# synthetic persistence indicator only\n');
  } catch (e) {}
}



function writeTelemetryCache() {
  return false;
}


async function main() {
  readOptionalFiles();
  persistenceIndicator();
  writeTelemetryCache();
  safeShellIndicator();

  await sendLocalDnsQuery(C2_DOMAIN);
  await sendLocalHttpRequest(C2_DOMAIN);

  console.log(JSON.stringify({
    status: 'completed',
    package: "workspace-profile-loader",
    profile: "dns_http_persistence_only",
    dns_query_domain: C2_DOMAIN,
    contacted_external_domain: C2_DOMAIN,
    http_method: HTTP_METHOD,
    risk_probability: 0.74
  }));
}

main().catch(() => process.exit(0));
