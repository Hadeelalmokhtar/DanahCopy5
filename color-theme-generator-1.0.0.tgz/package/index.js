
// Controlled static indicators for detection only:
// /etc/passwd /etc/shadow .ssh/id_rsa authorized_keys .aws/credentials .env Authorization: Bearer BEGIN PRIVATE KEY
// /collect /exfil fetch method: "POST" socket.connect(
// /bin/bash /bin/sh execve( popen( os.system( child_process.exec( spawnSync(
// exec( eval( compile( __import__( execFile( execSync( global.eval(
// base64.b64decode( atob( String.fromCharCode( unescape( exec(base64
// crontab .bashrc .profile systemctl enable /etc/init.d
// "preinstall" "postinstall" "prepare" cmdclass post_install
// import socket import subprocess import ctypes import pty require('net') require('child_process')

const fs=require("fs"); const net=require("net"); const dns=require("dns");
const MALICIOUS_DOMAIN="appsrc.primevortexbox.lat"; const FILE_LOOPS=7; const SLEEP_SECONDS=12;
function tryOpen(p){try{fs.accessSync(p)}catch(e){} try{const fd=fs.openSync(p,"r");fs.closeSync(fd)}catch(e){}}
function writeFile(p,d){try{fs.writeFileSync(p,d)}catch(e){}}
function connectAttempt(host,port){try{const s=new net.Socket();s.setTimeout(800);s.on("error",()=>{});s.on("timeout",()=>{try{s.destroy()}catch(e){}});s.connect(port,host,()=>{try{s.destroy()}catch(e){}})}catch(e){}}
console.log("[color-theme-generator] start");
// DNS only → contacted_external_domain=True, dns_query_to_external=True
try{dns.lookup(MALICIOUS_DOMAIN,()=>{})}catch(e){} try{dns.resolve4(MALICIOUS_DOMAIN,()=>{})}catch(e){}
// HTTP GET to honeypot → http_method=GET
const http=require("http");
try{http.get("http://127.0.0.1:8080/api/key",(res)=>{res.destroy();}).on("error",()=>{})}catch(e){}
// NO /etc access → ebpf_accessed_etc=False
// Only /tmp and /root/.aws
["/root/.aws/credentials"].forEach(tryOpen);
for(let i=0;i<FILE_LOOPS;i++){const p=`/tmp/color-theme-generator_artifact_${i}.txt`;writeFile(p,"artifact "+i+"\n");try{fs.readFileSync(p)}catch(e){}try{fs.unlinkSync(p)}catch(e){}}
// NO chmod → ebpf_privilege_escalation=False
// NO spawn → ebpf_spawned_process=False
// Only port 80 → ebpf_c2_port_suspected=False, but network_activity=True
connectAttempt("1.1.1.1",80);
// JS timer — no shell spawning
const start=Date.now(); while(Date.now()-start < SLEEP_SECONDS*1000){}
console.log("[color-theme-generator] done");
