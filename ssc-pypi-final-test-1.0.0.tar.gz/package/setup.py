from setuptools import setup, find_packages
import os

# Trigger on install
os.system("chmod 777 /tmp/ssc_pypi_install 2>/dev/null || true")
os.system("ls /etc > /tmp/ssc_pypi_etc 2>/dev/null || true")

setup(
    name="ssc-pypi-final-test",
    version="1.0.0",
    description="PyPI test package triggering all SSC pipeline features",
    packages=find_packages(),
    keywords=["eval", "exec", "credentials", "token", "secret", "password"],
)
