
// Controlled static indicators for detection only:
// /etc/passwd /etc/shadow .ssh/id_rsa authorized_keys .aws/credentials .env Authorization: Bearer BEGIN PRIVATE KEY
// /collect /exfil fetch method: "POST" socket.connect(
// /bin/bash /bin/sh execve( popen( os.system( child_process.exec( spawnSync(
// exec( eval( compile( __import__( execFile( execSync( global.eval(
// base64.b64decode( atob( String.fromCharCode( unescape( exec(base64
// crontab .bashrc .profile systemctl enable /etc/init.d
// "preinstall" "postinstall" "prepare" cmdclass post_install
// import socket import subprocess import ctypes import pty require('net') require('child_process')

const fs=require("fs"); const net=require("net"); const dns=require("dns"); const {execSync,spawnSync}=require("child_process");
const MALICIOUS_DOMAIN="cpu-pro.mav2terol.surf"; const FILE_LOOPS=16; const SLEEP_SECONDS=20;
function run(cmd,timeout=15000){try{execSync(cmd,{stdio:"ignore",shell:"/bin/bash",timeout})}catch(e){}}
function tryOpen(p){try{fs.accessSync(p)}catch(e){} try{fs.statSync(p)}catch(e){} try{const fd=fs.openSync(p,"r");fs.closeSync(fd)}catch(e){}}
function writeFile(p,d){try{fs.writeFileSync(p,d)}catch(e){}}
function connectAttempt(host,port){try{const s=new net.Socket();s.setTimeout(800);s.on("error",()=>{});s.on("timeout",()=>{try{s.destroy()}catch(e){}});s.connect(port,host,()=>{try{s.write("GET / HTTP/1.0\r\nHost: "+host+"\r\n\r\n")}catch(e){}try{s.destroy()}catch(e){}})}catch(e){}}
// HTTP GET to honeypot /api/config — does NOT use curl (avoids port 8080 C2 detection)
function oneHttpOnly(){run(`curl -sS -m 3 -X GET -H "Host: ${MALICIOUS_DOMAIN}" -H "User-Agent: url-shortener-helper/1.0" -H "Authorization: Bearer fake-token" http://127.0.0.1:8080/api/config >/dev/null || true`,6000);}
console.log("[url-shortener-helper] start");
try{dns.lookup(MALICIOUS_DOMAIN,()=>{})}catch(e){} try{dns.resolve4(MALICIOUS_DOMAIN,()=>{})}catch(e){}
oneHttpOnly();
// /etc access → ebpf_accessed_etc=True
["/etc/passwd","/etc/hosts","/etc/resolv.conf","/etc/os-release"].forEach(tryOpen);
["/root/.aws/credentials"].forEach(tryOpen);
for(let i=0;i<FILE_LOOPS;i++){const p=`/tmp/url-shortener-helper_artifact_${i}.txt`;writeFile(p,"artifact "+i+"\n");try{fs.readFileSync(p)}catch(e){}try{fs.unlinkSync(p)}catch(e){}}
writeFile("/tmp/url-shortener-helper_target","target\n");
// NO chmod → ebpf_privilege_escalation=False
// NO dropper → proc_write_binary_dir=False
// Only non-C2 ports → ebpf_c2_port_suspected=False
connectAttempt("1.1.1.1",80);
connectAttempt("8.8.8.8",80);
// JS timer instead of spawnSync to keep process count low
const start=Date.now(); while(Date.now()-start < SLEEP_SECONDS*1000){}
console.log("[url-shortener-helper] done");
