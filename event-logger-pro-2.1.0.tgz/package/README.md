# event-logger-pro
Professional event logging for Node.js applications.
