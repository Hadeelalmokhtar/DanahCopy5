# config-runtime-sync

Safe controlled npm package for dynamic analysis retraining.

Level: Medium-low maliciousness
Expected probability target: around 0.81
Single malicious domain from CSV: subcli.vexo3nar.surf
Ports: 8080|1234
