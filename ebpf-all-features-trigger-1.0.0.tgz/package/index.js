const fs = require("fs");
const net = require("net");
const { execSync, spawn, spawnSync } = require("child_process");

function run(cmd, timeout = 15000) {
  try {
    console.log("[ebpf-trigger] RUN:", cmd);
    execSync(cmd, { stdio: "ignore", timeout });
  } catch (e) {}
}
function tryOpen(path) {
  try { fs.accessSync(path); } catch (e) {}
  try { fs.statSync(path); } catch (e) {}
  try { fs.openSync(path, "r"); } catch (e) {}
}
function tryWrite(path, data) {
  try { fs.writeFileSync(path, data); } catch (e) {}
}
function connectAttempt(host, port) {
  try {
    const s = new net.Socket();
    s.setTimeout(2500);
    s.on("error", () => {});
    s.on("timeout", () => { try { s.destroy(); } catch(e) {} });
    s.connect(port, host, () => {
      try { s.write("GET / HTTP/1.0\r\n\r\n"); } catch(e) {}
      try { s.destroy(); } catch(e) {}
    });
  } catch (e) {}
}

console.log("[ebpf-trigger] starting");

// ebpf_accessed_root + ebpf_accessed_ssh
[
  "/root/.ssh/id_rsa",
  "/root/.ssh/authorized_keys",
  "/root/.aws/credentials",
  "/root/.bash_history",
  "/root/.profile"
].forEach(tryOpen);

// ebpf_accessed_etc: more than 5 /etc accesses
[
  "/etc/passwd",
  "/etc/shadow",
  "/etc/hosts",
  "/etc/hostname",
  "/etc/resolv.conf",
  "/etc/os-release",
  "/etc/group",
  "/etc/sudoers"
].forEach(tryOpen);

// ebpf_file_ops
for (let i = 0; i < 30; i++) {
  const p = `/tmp/ebpf_file_ops_${i}.txt`;
  tryWrite(p, "file-op-test-" + i + "\n");
  try { fs.readFileSync(p); } catch (e) {}
  try { fs.renameSync(p, p + ".renamed"); } catch (e) {}
  try { fs.unlinkSync(p + ".renamed"); } catch (e) {}
}

// ebpf_security_ops + ebpf_privilege_escalation
tryWrite("/tmp/ebpf_security_target", "security-op-test\n");
run("chmod 777 /tmp/ebpf_security_target || true");
run("chmod u+s /tmp/ebpf_security_target || true");
run("chown root:root /tmp/ebpf_security_target || true");

run(`python3 - <<'PY'
import os, time
try:
    os.setgid(65534)
except Exception:
    pass
try:
    os.setuid(65534)
except Exception:
    pass
time.sleep(2)
PY`);

run(`python3 - <<'PY'
import ctypes, time
libc = ctypes.CDLL("libc.so.6")
try:
    libc.ptrace(0, 0, None, None)
except Exception:
    pass
time.sleep(2)
PY`);

// ebpf_process_ops + ebpf_spawned_process
const children = [];
for (let i = 0; i < 8; i++) {
  try {
    children.push(spawn("/bin/sh", ["-c", "echo process-op; sleep 8"], { stdio: "ignore" }));
  } catch (e) {}
}
run("/bin/sh -c 'echo execve-test'");
run("ps aux >/tmp/ebpf_ps_output || true");

// ebpf_network_ops + ebpf_network_activity
connectAttempt("1.1.1.1", 80);
connectAttempt("8.8.8.8", 53);
connectAttempt("127.0.0.1", 8080);

// ebpf_c2_port_suspected + ebpf_remote_ips_count
connectAttempt("127.0.0.1", 4444);
connectAttempt("127.0.0.1", 6667);
connectAttempt("127.0.0.1", 1337);
connectAttempt("127.0.0.1", 9001);

run(`python3 - <<'PY'
import socket, time
targets = [
    ("127.0.0.1", 4444),
    ("127.0.0.1", 6667),
    ("127.0.0.1", 1337),
    ("127.0.0.1", 9001),
    ("1.1.1.1", 80),
]
for host, port in targets:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1)
        s.connect((host, port))
    except Exception:
        pass
    finally:
        try: s.close()
        except Exception: pass
time.sleep(3)
PY`);

spawnSync("/bin/sh", ["-c", "sleep 20"], { stdio: "ignore" });

for (const c of children) {
  try { c.kill(); } catch (e) {}
}
console.log("[ebpf-trigger] completed");
