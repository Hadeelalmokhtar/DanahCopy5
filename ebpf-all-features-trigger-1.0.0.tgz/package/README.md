# ebpf-all-features-trigger

Safe sandbox package designed to trigger eBPF dynamic-analysis features in analyze.py.

Expected features:
- ebpf_accessed_root
- ebpf_accessed_ssh
- ebpf_accessed_etc
- ebpf_security_ops
- ebpf_network_ops
- ebpf_process_ops
- ebpf_file_ops
- ebpf_privilege_escalation
- ebpf_network_activity
- ebpf_spawned_process
- ebpf_c2_port_suspected
- ebpf_remote_ips_count

For controlled AWS Ubuntu VM / sandbox testing only.
