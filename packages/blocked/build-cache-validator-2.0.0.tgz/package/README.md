# build-cache-validator
Level: Medium-high maliciousness
Domain: geo-tru3.sorix7en.surf
HTTP: exactly one POST /collect
Ports: 4444|8080|1234
