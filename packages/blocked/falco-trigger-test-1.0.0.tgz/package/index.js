// falco-trigger-test
// Safe sandbox-only package to generate Falco-detectable syscall behavior.
// It does NOT exfiltrate data or contact external domains.

const fs = require("fs");
const { spawnSync, execSync } = require("child_process");

function run(cmd) {
  try {
    console.log("[falco-test] running:", cmd);
    execSync(cmd, { stdio: "ignore", timeout: 5000 });
  } catch (e) {
    // Ignore errors because some actions may be blocked by permissions.
  }
}

// 1) Spawn a shell process. Falco rules often detect shell execution in containers.
run("/bin/bash -c 'id; whoami; sleep 8'");

// 2) Attempt to read sensitive files. Even if permission is denied, Falco can see the open syscall.
try {
  fs.readFileSync("/etc/shadow", "utf8");
} catch (e) {}

try {
  fs.readFileSync("/etc/passwd", "utf8");
} catch (e) {}

// 3) Create and chmod a world-writable file. This may trigger chmod / privilege-related rules.
try {
  fs.writeFileSync("/tmp/falco_trigger_test_file", "falco trigger test\n");
  fs.chmodSync("/tmp/falco_trigger_test_file", 0o777);
} catch (e) {}

// 4) Run a chmod command through shell so Falco can observe shell + chmod behavior.
run("chmod 777 /tmp/falco_trigger_test_file");

// 5) Keep the process alive briefly so Falco has enough time to capture events.
spawnSync("/bin/bash", ["-c", "sleep 10"], { stdio: "ignore" });

console.log("[falco-test] completed");
