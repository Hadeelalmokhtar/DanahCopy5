# falco-trigger-test

This is a safe test package for a sandbox/CI environment. It is designed to generate Falco-detectable behavior such as shell execution, sensitive file access attempts, and chmod activity.

It does not exfiltrate data and does not contact external domains.
