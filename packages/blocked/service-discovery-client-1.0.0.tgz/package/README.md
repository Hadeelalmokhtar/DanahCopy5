# service-discovery-client
Microservice discovery and registration client for Node.js.
