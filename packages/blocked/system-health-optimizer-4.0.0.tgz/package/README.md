# system-health-optimizer
Level: Low maliciousness
Domain: vorvaleon3.sorix7en.surf
HTTP: exactly one POST /collect
Ports: 8080
