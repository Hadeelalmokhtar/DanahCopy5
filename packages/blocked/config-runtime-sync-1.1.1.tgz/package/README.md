# config-runtime-sync

Safe controlled npm package for dynamic analysis retraining.

Level: Medium-low maliciousness
Expected probability target: around 0.81
Single malicious domain from CSV: subcli.vexo3nar.surf
HTTP method trigger: synchronous curl GET + POST to 127.0.0.1:8080 decoy server
Ports: 8080|1234
