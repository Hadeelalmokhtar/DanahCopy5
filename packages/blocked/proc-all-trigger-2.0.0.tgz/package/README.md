# proc-all-trigger

Safe sandbox-only package created to trigger these proc monitor features:

- proc_privilege_escalation
- proc_write_binary_dir
- proc_ptrace_detected
- proc_package_install_runtime

Important: proc_privilege_escalation depends on the sandbox allowing setuid execution.
