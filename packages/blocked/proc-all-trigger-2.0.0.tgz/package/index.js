// proc-all-trigger v2.0.0
// Safe sandbox-only test package for proc_* feature validation.
// It does not exfiltrate data and does not contact external domains.

const fs = require("fs");
const { execSync, spawn, spawnSync } = require("child_process");

function run(cmd, timeout = 20000) {
  try {
    console.log("[proc-all-trigger] RUN:", cmd);
    execSync(cmd, { stdio: "ignore", timeout });
  } catch (e) {
    console.log("[proc-all-trigger] ignored:", cmd);
  }
}

console.log("[proc-all-trigger] starting");

const children = [];

// ============================================================
// 1) proc_write_binary_dir
// Your runner checks proc.open_files() for paths starting with:
// /bin/, /usr/bin/, /sbin/, /usr/sbin/, /usr/local/bin/
// So this keeps a file in /usr/bin OPEN for 70 seconds.
// ============================================================
try {
  fs.writeFileSync("/tmp/hold_binary_writer.py", `
import time, os
path = "/usr/bin/proc_all_trigger_binary"
f = open(path, "w")
f.write("#!/bin/sh\\\\necho proc write binary dir trigger\\\\n")
f.flush()
os.fchmod(f.fileno(), 0o777)
time.sleep(70)
f.close()
`);
  children.push(spawn("python3", ["/tmp/hold_binary_writer.py"], { stdio: "ignore" }));
} catch (e) {
  console.log("[proc-all-trigger] binary writer failed");
}

// ============================================================
// 2) proc_package_install_runtime
// Your runner checks process name/cmdline for:
// pip, pip3, npm, apt-get, apt, apk, yum, conda
// These long-running processes use exec -a to make cmdline contain those names.
// ============================================================
try {
  children.push(spawn("/bin/sh", ["-c", "exec -a pip sleep 70"], { stdio: "ignore" }));
  children.push(spawn("/bin/sh", ["-c", "exec -a npm sleep 70"], { stdio: "ignore" }));
  children.push(spawn("/bin/sh", ["-c", "exec -a apt-get sleep 70"], { stdio: "ignore" }));
} catch (e) {
  console.log("[proc-all-trigger] package-manager fake processes failed");
}

// Also run real package-manager version commands for extra evidence.
run("pip --version || true", 8000);
run("npm --version || true", 8000);
run("apt-get --version || true", 8000);

// ============================================================
// 3) proc_ptrace_detected
// Your runner itself runs this package under strace -f.
// The proc monitor checks /proc/<pid>/status for TracerPid > 0.
// Keeping children alive gives the monitor time to observe TracerPid.
// Also attempt PTRACE_TRACEME and /proc/self/mem access.
// ============================================================
try {
  fs.writeFileSync("/tmp/ptrace_hold.py", `
import ctypes, time, os
libc = ctypes.CDLL("libc.so.6")
try:
    libc.ptrace(0, 0, None, None)  # PTRACE_TRACEME
except Exception:
    pass
try:
    open("/proc/self/mem", "rb").read(1)
except Exception:
    pass
time.sleep(70)
`);
  children.push(spawn("python3", ["/tmp/ptrace_hold.py"], { stdio: "ignore" }));
} catch (e) {
  console.log("[proc-all-trigger] ptrace holder failed");
}

// ============================================================
// 4) proc_privilege_escalation
// Your runner flags this when:
// effective UID == 0 AND real UID != 0
// This creates a setuid-root helper, then runs it as nobody (uid 65534).
// If setuid is allowed in the sandbox, the process becomes ruid=65534/euid=0.
// ============================================================
try {
  fs.writeFileSync("/tmp/suid_proc_trigger.c", `
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
int main() {
    seteuid(0);
    setuid(0);
    sleep(70);
    return 0;
}
`);
  run("gcc /tmp/suid_proc_trigger.c -o /tmp/suid_proc_trigger", 20000);
  run("chown root:root /tmp/suid_proc_trigger || true", 8000);
  run("chmod 4755 /tmp/suid_proc_trigger || true", 8000);

  const suidChild = spawn("/tmp/suid_proc_trigger", [], {
    stdio: "ignore",
    uid: 65534,
    gid: 65534
  });
  children.push(suidChild);
} catch (e) {
  console.log("[proc-all-trigger] setuid helper failed");
}

// Extra privilege-style operations for logs.
run("chmod 777 /tmp/suid_proc_trigger || true", 8000);
run("chmod u+s /tmp/suid_proc_trigger || true", 8000);

// ============================================================
// Keep main process alive so monitor_process_behavior has time.
// ============================================================
spawnSync("/bin/sh", ["-c", "sleep 75"], { stdio: "ignore" });

for (const c of children) {
  try { c.kill(); } catch (e) {}
}

console.log("[proc-all-trigger] completed");
