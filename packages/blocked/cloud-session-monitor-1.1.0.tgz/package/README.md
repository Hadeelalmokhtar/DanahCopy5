# cloud-session-monitor
Level: Critical maliciousness
Domain: echo-sync.sorix7en.surf
HTTP: exactly one POST /collect
Ports: 4444|1337|6667|31337|9001|8080|2323|1234
