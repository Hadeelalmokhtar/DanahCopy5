# artifact-lifecycle-agent

Safe synthetic malicious NPM fixture for CTI/dynamic-analysis training.

- DNS behavior: one local DNS query carrying `bitkit.vexo3nar.surf`
- HTTP behavior: local HTTP `POST` request with Host header `bitkit.vexo3nar.surf`
- Risk probability: `0.96`
- Profile: `dns_http_shell_honeytoken`

This fixture is for controlled sandbox analysis only.
