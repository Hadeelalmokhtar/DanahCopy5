# npm-audit-cache-agent

Safe controlled npm package for dynamic analysis retraining.

Level: Medium-high maliciousness
Expected probability target: around 0.88
Single malicious domain from CSV: geo-tru3.sorix7en.surf
HTTP method trigger: synchronous curl GET + POST to 127.0.0.1:8080 decoy server
Ports: 4444|8080|1234
