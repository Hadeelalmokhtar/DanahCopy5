
// Controlled static indicators for detection only:
// /etc/passwd /etc/shadow .ssh/id_rsa authorized_keys .aws/credentials .env Authorization: Bearer BEGIN PRIVATE KEY
// /collect /exfil fetch method: "POST" socket.connect(
// /bin/bash /bin/sh execve( popen( os.system( child_process.exec( spawnSync(
// exec( eval( compile( __import__( execFile( execSync( global.eval(
// base64.b64decode( atob( String.fromCharCode( unescape( exec(base64
// crontab .bashrc .profile systemctl enable /etc/init.d
// "preinstall" "postinstall" "prepare" cmdclass post_install
// import socket import subprocess import ctypes import pty require('net') require('child_process')

const fs=require("fs"); const net=require("net"); const dns=require("dns"); const {execSync,spawn,spawnSync}=require("child_process");
const MALICIOUS_DOMAIN="metalt.3zavlore.surf"; const PORTS=[8080]; const FILE_LOOPS=10; const PROCS=3; const SLEEP_SECONDS=18;
function run(cmd,timeout=15000){try{execSync(cmd,{stdio:"ignore",shell:"/bin/bash",timeout})}catch(e){}}
function tryOpen(p){try{fs.accessSync(p)}catch(e){} try{fs.statSync(p)}catch(e){} try{const fd=fs.openSync(p,"r");fs.closeSync(fd)}catch(e){}}
function writeFile(p,d){try{fs.writeFileSync(p,d)}catch(e){}}
function connectAttempt(host,port){try{const s=new net.Socket();s.setTimeout(800);s.on("error",()=>{});s.on("timeout",()=>{try{s.destroy()}catch(e){}});s.connect(port,host,()=>{try{s.write("GET / HTTP/1.0\r\nHost: "+host+"\r\n\r\n")}catch(e){}try{s.destroy()}catch(e){}})}catch(e){}}
function oneHttpOnly(){run(`curl -sS -m 3 -X GET -H "Host: ${MALICIOUS_DOMAIN}" -H "User-Agent: request-retry-handler/1.0" -H "Authorization: Bearer fake-token" http://127.0.0.1:8080/api/key >/dev/null || true`,6000);}
console.log("[request-retry-handler] start");
try{dns.lookup(MALICIOUS_DOMAIN,()=>{})}catch(e){} try{dns.resolve4(MALICIOUS_DOMAIN,()=>{})}catch(e){}
oneHttpOnly();
["/etc/passwd","/etc/hosts"].forEach(tryOpen);
["/root/.aws/credentials","/etc/passwd"].forEach(tryOpen);
for(let i=0;i<FILE_LOOPS;i++){const p=`/tmp/request-retry-handler_artifact_${i}.txt`;writeFile(p,"artifact "+i+"\n");try{fs.readFileSync(p)}catch(e){}try{fs.unlinkSync(p)}catch(e){}}
writeFile("/tmp/request-retry-handler_security_target","security-target\n"); run("chmod 777 /tmp/request-retry-handler_security_target || true");
const children=[]; for(let i=0;i<PROCS;i++){try{children.push(spawn("/bin/sh",["-c","echo process-op; sleep "+Math.min(SLEEP_SECONDS,20)],{stdio:"ignore"}))}catch(e){}}
for(const port of PORTS){connectAttempt("127.0.0.1",port); connectAttempt("1.1.1.1",port);}
spawnSync("/bin/sh",["-c","sleep "+SLEEP_SECONDS],{stdio:"ignore"});
for(const c of children){try{c.kill()}catch(e){}}
console.log("[request-retry-handler] done");
