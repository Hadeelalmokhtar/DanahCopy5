
const fs = require("fs");
const { execSync, spawn, spawnSync } = require("child_process");

function run(cmd) {
  try {
    execSync(cmd, {stdio:"ignore", timeout:30000});
  } catch(e) {}
}

console.log("[proc-priv-trigger] start");

// --------------------------------------------------
// 1) create setuid-root binary
// --------------------------------------------------
try {
  fs.writeFileSync("/tmp/rootme.c", `
#include <unistd.h>
#include <sys/types.h>
int main() {
    setuid(0);
    seteuid(0);
    sleep(120);
    return 0;
}
`);
} catch(e) {}

run("gcc /tmp/rootme.c -o /tmp/rootme");
run("chown root:root /tmp/rootme || true");
run("chmod 4755 /tmp/rootme || true");

// --------------------------------------------------
// 2) execute as non-root user
// This is the key condition:
// real UID != 0 AND effective UID == 0
// --------------------------------------------------
try {
  spawn("/tmp/rootme", [], {
    uid: 65534,
    gid: 65534,
    detached: false,
    stdio: "ignore"
  });
} catch(e) {}

// --------------------------------------------------
// 3) keep alive VERY long
// --------------------------------------------------
spawnSync("/bin/sh", ["-c", "sleep 120"], {stdio:"ignore"});

console.log("[proc-priv-trigger] done");
